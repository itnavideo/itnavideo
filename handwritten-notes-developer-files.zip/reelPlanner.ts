import {normalizeTranscriptForPlanner} from './hinglishTranscript';
import {createManagedReelPlan} from './openaiReelDirector';
import {extractScriptDetails, type ScriptDetails} from './scriptDetails';
import {matchVisualAssetsForScript} from './visualAssetCatalog';
import {z} from 'zod';

export type ReelPlannerProvider = 'local' | 'openai';

export type ReelWord = {
  word: string;
  start: number;
  end: number;
};

export type ReelTranscriptSegment = {
  id?: string | number;
  start: number;
  end: number;
  text: string;
};

export type ReelPlanRequest = {
  transcript: string;
  words?: ReelWord[];
  timestampSegments?: ReelTranscriptSegment[];
  durationSeconds?: number;
  topic?: string;
  topicTitle?: string;
  emotion?: string;
  mediaType?: 'audio' | 'video' | 'image';
  languageHint?: 'english' | 'hinglish';
  template?: string;
  design?: string;
  visualMode?: string;
  selectedAssets?: Record<string, string[]>;
  constraints?: string[];
  scriptDetails?: ScriptDetails;
  dryRun?: boolean;
};

export type ReelTimelineScene = {
  id: string;
  start: number;
  end: number;
  purpose: 'hook' | 'explain' | 'proof' | 'cta';
  script: string;
  density: 'low' | 'medium' | 'high';
  visualEnergy: number;
  speechImportance: number;
  sceneComplexity: number;
  visualMode: 'videoExplainer' | 'notes' | 'videoCaption' | 'imageStory';
  primaryFocus: 'topVisual' | 'notesCanvas' | 'captions' | 'images';
  secondarySupport?: Array<'titleCard'>;
};

export type ReelTemplateName = 'VIDEO_EXPLAINER' | 'HANDWRITTEN_NOTES' | 'VIDEO_CAPTION' | 'IMAGE_STORY';
export const REEL_TEMPLATE_REGISTRY = {
  VIDEO_EXPLAINER: {
    templateName: 'VIDEO_EXPLAINER',
    compositionId: 'VIDEO-EXPLAINER',
    allowedMedia: ['audio', 'video'],
    transcriptRequirement: 'required',
    plannerMode: 'videoExplainer',
    mediaFit: 'videoExplainer',
    schema: () => getReelTemplateSchema('VIDEO_EXPLAINER'),
  },
  HANDWRITTEN_NOTES: {
    templateName: 'HANDWRITTEN_NOTES',
    compositionId: 'HANDWRITTEN-NOTES',
    allowedMedia: ['audio', 'video'],
    transcriptRequirement: 'required',
    plannerMode: 'notes',
    mediaFit: 'notes',
    schema: () => getReelTemplateSchema('HANDWRITTEN_NOTES'),
  },
  VIDEO_CAPTION: {
    templateName: 'VIDEO_CAPTION',
    compositionId: 'VIDEO-CAPTION',
    allowedMedia: ['video'],
    transcriptRequirement: 'required',
    plannerMode: 'videoCaption',
    mediaFit: 'videoCaption',
    schema: () => getReelTemplateSchema('VIDEO_CAPTION'),
  },
  IMAGE_STORY: {
    templateName: 'IMAGE_STORY',
    compositionId: 'IMAGE-STORY',
    allowedMedia: ['image', 'audio', 'video'],
    transcriptRequirement: 'audio-or-video',
    plannerMode: 'imageStory',
    mediaFit: 'imageStory',
    schema: () => getReelTemplateSchema('IMAGE_STORY'),
  },
} as const satisfies Record<string, {
  templateName: ReelTemplateName;
  compositionId: string;
  allowedMedia: ReadonlyArray<'audio' | 'video' | 'image'>;
  transcriptRequirement: 'required' | 'audio-or-video';
  plannerMode: 'videoExplainer' | 'notes' | 'videoCaption' | 'imageStory';
  mediaFit: 'videoExplainer' | 'notes' | 'videoCaption' | 'imageStory';
  schema: () => z.ZodTypeAny;
}>;
export type ReelOverlayLayout = 'headlineCard' | 'splitExplainer' | 'statCard' | 'warningCard' | 'checklist' | 'ctaCard';
export type ReelPrimaryVisualType = 'uploadedMedia' | 'image' | 'icon' | 'chart' | 'document' | 'waveform' | 'mockup' | 'none';
export type ReelPrimaryVisualMotion = 'slowZoom' | 'panLeft' | 'float' | 'pop' | 'slideUp' | 'parallax';
export type ReelOverlayAnimation = 'fadeUp' | 'popIn' | 'slideUp' | 'countUp' | 'warningPulse';
export type ReelOverlayEmotion = 'urgent' | 'informative' | 'serious' | 'motivational';
export type ReelOverlayVisualRole = 'topVideo' | 'bottomOverlay' | 'background' | 'assetInsert';
export type ReelPrimaryVisual = {
  type: ReelPrimaryVisualType;
  assetId?: string;
  prompt?: string;
  label?: string;
  motion?: ReelPrimaryVisualMotion;
};
export type ReelAssetPlan = {
  suggested: string[];
  required: string[];
  avoid: string[];
};

type ReelCaptionStylePreset = 'boldCreator' | 'cleanSubtitle' | 'podcast' | 'screenRecord' | 'productDemo';
type ReelCaptionMode = 'wordHighlight' | 'phraseReveal' | 'segmentCaption';
type ReelCaptionItem = {
  id?: string;
  start: number;
  end: number;
  text: string;
  lines?: string[];
  words?: Array<ReelWord & {lineIndex?: number; wordIndex?: number}>;
  mode?: ReelCaptionMode;
  stylePreset?: ReelCaptionStylePreset;
};
type ReelImageStoryMotionType = 'slowZoomIn' | 'slowZoomOut' | 'panLeft' | 'panRight' | 'panUp' | 'panDown' | 'parallax' | 'pushIn' | 'reveal';
type ReelImageStoryStylePreset = 'cinematic' | 'product' | 'motivation' | 'education' | 'documentary';
type ReelImageStoryImage = {
  id: string;
  src: string;
  source: 'uploaded' | 'selectedAsset' | 'generated' | 'fallback';
  width?: number;
  height?: number;
  alt?: string;
  category?: string;
  safeCrop?: {
    focusX: number;
    focusY: number;
    avoidTextZone?: 'top' | 'bottom' | 'center' | 'none';
  };
};
type ReelImageStoryScene = {
  id: string;
  start: number;
  end: number;
  imageId: string;
  imageRole: 'hero' | 'detail' | 'proof' | 'transition' | 'ending';
  beatText?: string;
  label?: string;
  title?: string;
  motion: {
    type: ReelImageStoryMotionType;
    intensity: 'low' | 'medium';
    focusX?: number;
    focusY?: number;
  };
  textOverlay?: {
    enabled: boolean;
    text?: string;
    position: 'topSafe' | 'lowerThird' | 'centerSoft' | 'none';
    maxLines: 1 | 2;
    style: 'minimalTitle' | 'smallLabel' | 'punchLine' | 'productTag';
  };
  transition?: {
    in: 'fade' | 'cut' | 'slide' | 'blurReveal';
    out: 'fade' | 'cut' | 'blur';
  };
};

export type ReelPlanResult = {
  provider: ReelPlannerProvider;
  model: string;
  template: ReelTemplateName;
  templateName: ReelTemplateName;
  analysis: {
    durationSeconds: number;
    speechDensity: 'slow' | 'medium' | 'fast';
    hookStrength: number;
    language: 'english' | 'hinglish';
  };
  timeline: ReelTimelineScene[];
  assets: ReelAssetPlan;
  scriptDetails: ScriptDetails;
  renderProps: {
    brand: string;
    topicTitle?: string;
    design?: string;
    templateName: ReelTemplateName;
    scriptDetails: ScriptDetails;
    mediaType: 'video' | 'audio' | 'image';
    mediaFit?: 'videoExplainer' | 'notes' | 'videoCaption' | 'imageStory';
    durationSeconds: number;
    overlayTimeline: Array<{
      id: string;
      start: number;
      end: number;
      type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta';
      label: string;
      text: string;
      body?: string;
      accentWord?: string;
      align: 'left' | 'center';
      sfx?: 'softPop' | 'softTick' | 'softChime';
      layout: ReelOverlayLayout;
      visual: string;
      visualRole: ReelOverlayVisualRole;
      primaryVisual: ReelPrimaryVisual;
      animation: ReelOverlayAnimation;
      emotion: ReelOverlayEmotion;
      words?: ReelWord[];
      sceneType?: string;
      noteItems?: Array<{text: string; emphasis?: string; icon?: 'check' | 'dot' | 'warning' | 'star' | 'number'}>;
      diagram?: {type: 'flowchart' | 'timeline' | 'mindmap' | 'comparison'; nodes: string[]; activeNode?: string};
      annotations?: Array<{type: 'highlight_swipe' | 'red_circle' | 'arrow_diagram' | 'underline' | 'side_note'; targetText: string; label?: string}>;
      revealPlan?: Array<{text: string; start: number; end: number; token: string}>;
    }>;
    captions: ReelCaptionItem[];
    captionPlan?: {
      mode: ReelCaptionMode;
      position: 'bottomSafe' | 'middleLower' | 'topSafe';
      avoidArea?: 'faceCenter' | 'screenCenter' | 'productCenter' | 'none';
      captions: ReelCaptionItem[];
    };
    videoStyle?: {
      fit: 'cover' | 'contain';
      cropMode: 'center' | 'faceSafe' | 'screenSafe';
      backgroundBlur?: boolean;
    };
    safeZones?: {
      top: number;
      bottom: number;
      left: number;
      right: number;
    };
    source?: {
      mode: 'singleImage' | 'multiImage' | 'audioImageStory' | 'imageOnlyStory';
      topic?: string;
      prompt?: string;
    };
    images?: ReelImageStoryImage[];
    storyPlan?: {
      languageMode: 'english' | 'roman_hinglish';
      stylePreset: ReelImageStoryStylePreset;
      scenes: ReelImageStoryScene[];
    };
    imageSources?: string[];
    imageScenes?: Array<{
      id?: string;
      start: number;
      end: number;
      imageSrc?: string;
      imageFit?: 'cover' | 'contain' | 'smart';
      title: string;
      body?: string;
      accentWord?: string;
      label?: string;
      tone?: 'hook' | 'proof' | 'warning' | 'action' | 'cta' | 'point';
    }>;
  };
  validation: {
    status: 'complete' | 'repaired' | 'blocked';
    repairable: boolean;
    warnings: string[];
    notes: string[];
    renderAllowed: boolean;
    renderBlockReason?: string;
    qualityScore: number;
    qualityBand: 'professional' | 'warning' | 'blocked';
    qualityChecks: string[];
    qualityFindings: [];
    pipeline: Array<{
      step: string;
      status: 'complete';
      detail: string;
    }>;
    openAiCallsUsed: number;
  };
};

const MAX_SECONDS = 60;
const MIN_OVERLAY_SECONDS = 4.2;
const MAX_OVERLAY_SECONDS = 8.5;
const reelWordSchema = z.object({
  word: z.string().min(1).max(80),
  start: z.number().nonnegative(),
  end: z.number().positive(),
});
const captionWordSchema = reelWordSchema.extend({
  lineIndex: z.number().int().nonnegative().max(1).optional(),
  wordIndex: z.number().int().nonnegative().max(14).optional(),
});
const captionItemSchema = z.object({
  start: z.number().nonnegative(),
  end: z.number().positive(),
  text: z.string().min(1).max(120),
  lines: z.array(z.string().min(1).max(56)).min(1).max(2).optional(),
  words: z.array(captionWordSchema).optional(),
  mode: z.enum(['wordHighlight', 'phraseReveal', 'segmentCaption']).optional(),
  stylePreset: z.enum(['boldCreator', 'cleanSubtitle', 'podcast', 'screenRecord', 'productDemo']).optional(),
}).refine((caption) => caption.end > caption.start, {
  message: 'Caption end must be after start.',
});
const reelPrimaryVisualSchema = z.object({
  type: z.enum(['uploadedMedia', 'image', 'icon', 'chart', 'document', 'waveform', 'mockup', 'none']),
  assetId: z.string().max(80).optional(),
  prompt: z.string().max(180).optional(),
  label: z.string().max(48).optional(),
  motion: z.enum(['slowZoom', 'panLeft', 'float', 'pop', 'slideUp', 'parallax']).optional(),
});
const videoExplainerOverlaySchema = z.object({
  id: z.string().min(1).max(32),
  start: z.number().nonnegative(),
  end: z.number().positive(),
  type: z.enum(['hook', 'point', 'stat', 'warning', 'quote', 'cta']),
  label: z.string().min(1).max(32),
  text: z.string().min(1).max(90),
  body: z.string().max(150).optional(),
  accentWord: z.string().max(24).optional(),
  align: z.enum(['left', 'center']),
  sfx: z.enum(['softPop', 'softTick', 'softChime']).optional(),
  layout: z.enum(['headlineCard', 'splitExplainer', 'statCard', 'warningCard', 'checklist', 'ctaCard']),
  visual: z.string().min(1).max(180),
  visualRole: z.enum(['topVideo', 'bottomOverlay', 'background', 'assetInsert']),
  primaryVisual: reelPrimaryVisualSchema,
  animation: z.enum(['fadeUp', 'popIn', 'slideUp', 'countUp', 'warningPulse']),
  emotion: z.enum(['urgent', 'informative', 'serious', 'motivational']),
  words: z.array(reelWordSchema).optional(),
  sceneType: z.string().max(48).optional(),
  noteItems: z.array(z.object({
    text: z.string().min(1).max(72),
    emphasis: z.string().max(24).optional(),
    icon: z.enum(['check', 'dot', 'warning', 'star', 'number']).optional(),
  })).max(4).optional(),
  diagram: z.object({
    type: z.enum(['flowchart', 'timeline', 'mindmap', 'comparison']),
    nodes: z.array(z.string().min(1).max(28)).min(2).max(5),
    activeNode: z.string().max(28).optional(),
  }).optional(),
  annotations: z.array(z.object({
    type: z.enum(['highlight_swipe', 'red_circle', 'arrow_diagram', 'underline', 'side_note']),
    targetText: z.string().min(1).max(36),
    label: z.string().max(48).optional(),
  })).max(3).optional(),
  revealPlan: z.array(z.object({
    text: z.string().min(1).max(72),
    start: z.number().nonnegative(),
    end: z.number().positive(),
    token: z.string().min(1).max(32),
  })).max(8).optional(),
}).refine((overlay) => overlay.end > overlay.start, {
  message: 'Overlay end must be after start.',
});
const videoExplainerRenderPropsSchema = z.object({
  brand: z.string(),
  topicTitle: z.string().optional(),
  design: z.string().optional(),
  templateName: z.literal('VIDEO_EXPLAINER'),
  scriptDetails: z.unknown(),
  mediaType: z.enum(['video', 'audio', 'image']),
  mediaFit: z.enum(['videoExplainer', 'notes', 'videoCaption', 'imageStory']).optional(),
  durationSeconds: z.number().positive().max(MAX_SECONDS),
  overlayTimeline: z.array(videoExplainerOverlaySchema).min(1).max(18),
  captions: z.array(captionItemSchema),
});
const handwrittenNotesOverlaySchema = z.object({
  id: z.string().min(1).max(80),
  start: z.number().nonnegative(),
  end: z.number().positive(),
  type: z.enum(['hook', 'point', 'stat', 'warning', 'quote', 'cta']).catch('point'),
  label: z.string().max(80).optional(),
  text: z.string().min(1).max(180),
  body: z.string().max(260).optional(),
  accentWord: z.string().max(48).optional(),
  align: z.enum(['left', 'center']).optional(),
  sfx: z.enum(['softPop', 'softTick', 'softChime']).optional(),
  layout: z.string().max(80).optional(),
  visual: z.string().min(1).max(180).optional(),
  visualRole: z.string().max(80).optional(),
  primaryVisual: z.unknown().optional(),
  animation: z.string().max(80).optional(),
  emotion: z.string().max(80).optional(),
  words: z.array(reelWordSchema.passthrough()).optional(),
  sceneType: z.string().max(80).optional(),
  noteItems: z.array(z.record(z.string(), z.unknown())).optional(),
  diagram: z.record(z.string(), z.unknown()).optional(),
  annotations: z.array(z.record(z.string(), z.unknown())).optional(),
  revealPlan: z.array(z.record(z.string(), z.unknown())).optional(),
}).passthrough().refine((overlay) => overlay.end > overlay.start, {
  message: 'Overlay end must be after start.',
});

const handwrittenNotesRenderPropsSchema = z.object({
  brand: z.string(),
  topicTitle: z.string().optional(),
  design: z.string().optional(),
  templateName: z.literal('HANDWRITTEN_NOTES'),
  scriptDetails: z.unknown().optional(),
  mediaType: z.enum(['audio', 'video', 'image']),
  mediaFit: z.literal('notes').optional(),
  durationSeconds: z.number().positive().max(MAX_SECONDS),
  overlayTimeline: z.array(handwrittenNotesOverlaySchema).min(1).max(24),
  captions: z.array(z.unknown()).optional(),
}).passthrough();
const videoCaptionRenderPropsSchema = z.object({
  brand: z.string(),
  topicTitle: z.string().optional(),
  design: z.string().optional(),
  templateName: z.literal('VIDEO_CAPTION'),
  scriptDetails: z.unknown(),
  mediaType: z.literal('video'),
  mediaFit: z.literal('videoCaption').optional(),
  durationSeconds: z.number().positive().max(MAX_SECONDS),
  overlayTimeline: z.array(z.unknown()).optional(),
  captions: z.array(captionItemSchema.safeExtend({
    lines: z.array(z.string().min(1).max(56)).min(1).max(2),
    mode: z.enum(['wordHighlight', 'phraseReveal', 'segmentCaption']),
    stylePreset: z.enum(['boldCreator', 'cleanSubtitle', 'podcast', 'screenRecord', 'productDemo']),
  })).min(1).max(60),
  captionPlan: z.object({
    mode: z.enum(['wordHighlight', 'phraseReveal', 'segmentCaption']),
    position: z.enum(['bottomSafe', 'middleLower', 'topSafe']),
    avoidArea: z.enum(['faceCenter', 'screenCenter', 'productCenter', 'none']).optional(),
    captions: z.array(captionItemSchema.safeExtend({
      lines: z.array(z.string().min(1).max(56)).min(1).max(2),
      mode: z.enum(['wordHighlight', 'phraseReveal', 'segmentCaption']),
      stylePreset: z.enum(['boldCreator', 'cleanSubtitle', 'podcast', 'screenRecord', 'productDemo']),
    })).min(1).max(60),
  }),
  videoStyle: z.object({
    fit: z.enum(['cover', 'contain']),
    cropMode: z.enum(['center', 'faceSafe', 'screenSafe']),
    backgroundBlur: z.boolean().optional(),
  }),
  safeZones: z.object({
    top: z.number().nonnegative(),
    bottom: z.number().nonnegative(),
    left: z.number().nonnegative(),
    right: z.number().nonnegative(),
  }),
});
const imageStoryImageSchema = z.object({
  id: z.string().min(1).max(48),
  src: z.string().min(1).max(600),
  source: z.enum(['uploaded', 'selectedAsset', 'generated', 'fallback']),
  width: z.number().positive().optional(),
  height: z.number().positive().optional(),
  alt: z.string().max(120).optional(),
  category: z.string().max(48).optional(),
  safeCrop: z.object({
    focusX: z.number().min(0).max(1),
    focusY: z.number().min(0).max(1),
    avoidTextZone: z.enum(['top', 'bottom', 'center', 'none']).optional(),
  }).optional(),
});
const imageStorySceneSchema = z.object({
  id: z.string().min(1).max(48),
  start: z.number().nonnegative(),
  end: z.number().positive(),
  imageId: z.string().min(1).max(48),
  imageRole: z.enum(['hero', 'detail', 'proof', 'transition', 'ending']),
  beatText: z.string().max(80).optional(),
  label: z.string().max(38).optional(),
  title: z.string().max(80).optional(),
  motion: z.object({
    type: z.enum(['slowZoomIn', 'slowZoomOut', 'panLeft', 'panRight', 'panUp', 'panDown', 'parallax', 'pushIn', 'reveal']),
    intensity: z.enum(['low', 'medium']),
    focusX: z.number().min(0).max(1).optional(),
    focusY: z.number().min(0).max(1).optional(),
  }),
  textOverlay: z.object({
    enabled: z.boolean(),
    text: z.string().max(80).optional(),
    position: z.enum(['topSafe', 'lowerThird', 'centerSoft', 'none']),
    maxLines: z.union([z.literal(1), z.literal(2)]),
    style: z.enum(['minimalTitle', 'smallLabel', 'punchLine', 'productTag']),
  }).optional(),
  transition: z.object({
    in: z.enum(['fade', 'cut', 'slide', 'blurReveal']),
    out: z.enum(['fade', 'cut', 'blur']),
  }).optional(),
}).refine((scene) => scene.end > scene.start, {
  message: 'Image story scene end must be after start.',
});
const imageStoryRenderPropsSchema = z.object({
  brand: z.string(),
  topicTitle: z.string().optional(),
  design: z.string().optional(),
  templateName: z.literal('IMAGE_STORY'),
  scriptDetails: z.unknown(),
  mediaType: z.enum(['image', 'audio', 'video']),
  mediaFit: z.literal('imageStory').optional(),
  durationSeconds: z.number().positive().max(MAX_SECONDS),
  overlayTimeline: z.array(videoExplainerOverlaySchema).optional(),
  captions: z.array(captionItemSchema),
  source: z.object({
    mode: z.enum(['singleImage', 'multiImage', 'audioImageStory', 'imageOnlyStory']),
    topic: z.string().max(120).optional(),
    prompt: z.string().max(240).optional(),
  }),
  images: z.array(imageStoryImageSchema).min(1).max(24),
  storyPlan: z.object({
    languageMode: z.enum(['english', 'roman_hinglish']),
    stylePreset: z.enum(['cinematic', 'product', 'motivation', 'education', 'documentary']),
    scenes: z.array(imageStorySceneSchema).min(1).max(24),
  }),
  safeZones: z.object({
    top: z.number().nonnegative(),
    bottom: z.number().nonnegative(),
    left: z.number().nonnegative(),
    right: z.number().nonnegative(),
  }),
  imageSources: z.array(z.string().min(1).max(600)).min(1).max(24),
  imageScenes: z.array(z.object({
    id: z.string().max(48).optional(),
    start: z.number().nonnegative(),
    end: z.number().positive(),
    imageSrc: z.string().max(600).optional(),
    imageFit: z.enum(['cover', 'contain', 'smart']).optional(),
    title: z.string().min(1).max(86),
    body: z.string().max(150).optional(),
    accentWord: z.string().max(24).optional(),
    label: z.string().max(38).optional(),
    tone: z.enum(['hook', 'proof', 'warning', 'action', 'cta', 'point']).optional(),
  }).refine((scene) => scene.end > scene.start, {
    message: 'Image scene end must be after start.',
  })).min(1).max(24),
});

export function getReelTemplateSchema(templateName: ReelTemplateName): z.ZodTypeAny {
  if (templateName === 'HANDWRITTEN_NOTES') return handwrittenNotesRenderPropsSchema;
  if (templateName === 'VIDEO_CAPTION') return videoCaptionRenderPropsSchema;
  if (templateName === 'IMAGE_STORY') return imageStoryRenderPropsSchema;
  return videoExplainerRenderPropsSchema;
}

export async function createReelPlan(input: ReelPlanRequest): Promise<ReelPlanResult> {
  const localPlan = await createLocalReelPlan(input);
  if (input.dryRun || !process.env.OPENAI_API_KEY || getMaxOpenAiCallsPerRender() < 1) {
    return validateAndRepairReelPlan(localPlan);
  }

  try {
    const managed = await createManagedReelPlan({
      request: input,
      localPlan,
    });
    if (managed) return validateAndRepairReelPlan(managed);
  } catch {
    localPlan.validation.warnings.push('Managed planner failed; local repair planner was used.');
  }

  return validateAndRepairReelPlan(localPlan);
}

export function validateAndRepairReelPlan(plan: ReelPlanResult): ReelPlanResult {
  type ValidatedOverlay = ReelPlanResult['renderProps']['overlayTimeline'][number];
  const maxOpenAiCalls = getMaxOpenAiCallsPerRender();
  const durationSeconds = clampPlanNumber(plan.analysis.durationSeconds, 1, MAX_SECONDS);
  const warnings: string[] = [];
  let previousEnd = 0;
  let previousVisualKey = '';

  const overlayTimeline = plan.renderProps.overlayTimeline
    .map<ValidatedOverlay | null>((overlay, index) => {
      let start = clampPlanNumber(Number(overlay.start), 0, durationSeconds);
      let end = clampPlanNumber(Number(overlay.end), start + 1.2, durationSeconds);
      if (start < previousEnd - 0.05) {
        start = previousEnd;
        warnings.push('Overlapping scene timing was repaired before render.');
      }
      if (end <= start) {
        end = Math.min(durationSeconds, start + 1.2);
        warnings.push('Invalid scene duration was repaired before render.');
      }
      if (start >= durationSeconds || end <= start) return null;

      const text = cleanDisplayText(overlay.text || '').slice(0, 90);
      const body = cleanDisplayText(overlay.body || '').slice(0, 150);
      if (!text) {
        warnings.push('A scene with missing caption text was removed before render.');
        return null;
      }

      let visual = cleanDisplayText(overlay.visual || defaultValidationVisual(overlay.type)).slice(0, 180);
      const visualKey = normalizeVisualKey(visual);
      if (plan.templateName !== 'HANDWRITTEN_NOTES' && visualKey && visualKey === previousVisualKey) {
        visual = defaultValidationVisual(overlay.type);
        warnings.push('Repeated adjacent visual direction was repaired before render.');
      }
      previousVisualKey = normalizeVisualKey(visual);
      previousEnd = end;

      return {
        ...overlay,
        id: cleanDisplayText(overlay.id || `overlay-${index + 1}`).replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 32) || `overlay-${index + 1}`,
        start: roundTime(start),
        end: roundTime(end),
        label: cleanDisplayText(overlay.label || labelForType(overlay.type)).slice(0, 32),
        text,
        body,
        accentWord: cleanDisplayText(overlay.accentWord || pickAccentWord(text, plan.renderProps.topicTitle)).split(/\s+/)[0] || '',
        align: overlay.align === 'left' ? 'left' as const : 'center' as const,
        sfx: overlay.sfx === 'softPop' || overlay.sfx === 'softTick' || overlay.sfx === 'softChime'
          ? overlay.sfx
          : index === 0 ? 'softPop' as const : 'softTick' as const,
        layout: overlay.layout,
        visual,
        visualRole: overlay.visualRole,
        primaryVisual: normalizePrimaryVisual(overlay.primaryVisual, overlay, plan.renderProps.mediaType),
        animation: overlay.animation,
        emotion: overlay.emotion,
        ...normalizeHandwrittenOverlayMetadata(plan.templateName, {
          ...overlay,
          start: roundTime(start),
          end: roundTime(end),
          text,
          body,
          visual,
        }),
      };
    })
    .filter((overlay): overlay is ValidatedOverlay => overlay !== null);

  if (!overlayTimeline.length) {
    warnings.push('No valid scenes were available after plan validation.');
  }
  if (plan.validation.openAiCallsUsed > maxOpenAiCalls) {
    warnings.push(`OpenAI planning call count exceeded policy and was capped to ${maxOpenAiCalls}.`);
  }

  const captions = repairCaptionsForTemplate(plan.renderProps.captions, durationSeconds, plan.templateName, warnings);
  const imageStoryProps = plan.templateName === 'IMAGE_STORY'
    ? repairImageStoryProps(plan.renderProps, durationSeconds, warnings)
    : undefined;

  const renderProps = {
    ...plan.renderProps,
    durationSeconds,
    overlayTimeline,
    captions,
    ...(plan.templateName === 'VIDEO_CAPTION'
      ? {
          captionPlan: buildCaptionPlan(captions),
          videoStyle: normalizeVideoCaptionStyle(plan.renderProps.videoStyle),
          safeZones: normalizeSafeZones(plan.renderProps.safeZones),
        }
      : {}),
    ...(imageStoryProps || {}),
  };
  const schema = plan.templateName === 'VIDEO_CAPTION'
      ? videoCaptionRenderPropsSchema
      : plan.templateName === 'IMAGE_STORY'
        ? imageStoryRenderPropsSchema
      : videoExplainerRenderPropsSchema;
  const zodValidation = plan.templateName === 'HANDWRITTEN_NOTES'
    ? {success: true as const}
    : schema.safeParse(renderProps);
  if (!zodValidation.success) {
    warnings.push(`Render props schema failed: ${zodValidation.error.issues.slice(0, 3).map((issue) => issue.message).join(' ')}`);
  }

  const videoCaptionAllowed = plan.templateName !== 'VIDEO_CAPTION' || (
    renderProps.mediaType === 'video' &&
    captions.length > 0 &&
    captions.some((caption) => caption.mode === 'wordHighlight' || caption.mode === 'phraseReveal' || caption.mode === 'segmentCaption')
  );
  if (plan.templateName === 'VIDEO_CAPTION' && renderProps.mediaType !== 'video') {
    warnings.push('VIDEO_CAPTION render blocked because uploaded media is not video.');
  }
  if (plan.templateName === 'VIDEO_CAPTION' && !captions.length) {
    warnings.push('VIDEO_CAPTION render blocked because transcript-timed captions are missing.');
  }
  const imageStoryAllowed = plan.templateName !== 'IMAGE_STORY' || Boolean(imageStoryProps?.images?.length && imageStoryProps?.storyPlan?.scenes?.length);
  if (plan.templateName === 'IMAGE_STORY' && !imageStoryAllowed) {
    warnings.push('IMAGE_STORY render blocked because no usable image story scenes were available.');
  }
  const renderAllowed = (plan.templateName === 'IMAGE_STORY' ? imageStoryAllowed : overlayTimeline.length > 0) &&
    videoCaptionAllowed &&
    zodValidation.success &&
    plan.validation.renderAllowed !== false;
  const validationWarnings = uniqueStrings([
    ...plan.validation.warnings,
    ...warnings,
  ]);

  return {
    ...plan,
    analysis: {
      ...plan.analysis,
      durationSeconds,
    },
    timeline: overlayTimeline.map((overlay, index) => ({
      ...(plan.timeline[index] || plan.timeline.at(-1) || {
        id: overlay.id,
        start: overlay.start,
        end: overlay.end,
        purpose: index === 0 ? 'hook' as const : index === overlayTimeline.length - 1 ? 'cta' as const : 'explain' as const,
        script: overlay.text,
        density: 'medium' as const,
        visualEnergy: 0.5,
        speechImportance: 0.7,
        sceneComplexity: 0.4,
        visualMode: plan.templateName === 'HANDWRITTEN_NOTES' ? 'notes' as const : plan.templateName === 'VIDEO_CAPTION' ? 'videoCaption' as const : plan.templateName === 'IMAGE_STORY' ? 'imageStory' as const : 'videoExplainer' as const,
        primaryFocus: plan.templateName === 'HANDWRITTEN_NOTES' ? 'notesCanvas' as const : plan.templateName === 'VIDEO_CAPTION' ? 'captions' as const : plan.templateName === 'IMAGE_STORY' ? 'images' as const : 'topVisual' as const,
      }),
      id: overlay.id,
      start: overlay.start,
      end: overlay.end,
      script: [overlay.text, overlay.body].filter(Boolean).join('. '),
    })),
    renderProps,
    validation: {
      ...plan.validation,
      status: renderAllowed ? validationWarnings.length ? 'repaired' : plan.validation.status : 'blocked',
      warnings: validationWarnings,
      notes: uniqueStrings([
        ...plan.validation.notes,
        'Final render props passed transcript-window, timing, text, and visual validation.',
      ]),
      renderAllowed,
      renderBlockReason: renderAllowed
        ? plan.validation.renderBlockReason
        : plan.templateName === 'VIDEO_CAPTION' && !videoCaptionAllowed
          ? 'Caption render blocked because transcript is missing or invalid.'
          : plan.templateName === 'IMAGE_STORY' && !imageStoryAllowed
            ? 'Image Story render blocked because no usable image exists.'
          : zodValidation.success ? 'No valid transcript-based scenes were available for render.' : 'Render props failed schema validation before render.',
      qualityScore: renderAllowed ? plan.validation.qualityScore : Math.min(plan.validation.qualityScore, 50),
      qualityBand: renderAllowed ? plan.validation.qualityBand : 'blocked',
      pipeline: [
        ...plan.validation.pipeline.filter((step) => step.step !== 'Validation'),
        {
          step: 'Validation',
          status: 'complete' as const,
          detail: renderAllowed
            ? `Zod checked ${overlayTimeline.length} transcript-timed scenes before render.`
            : zodValidation.success
              ? 'Blocked render because no valid transcript-timed scenes were available.'
              : 'Blocked render because render props failed Zod schema validation.',
        },
      ],
      openAiCallsUsed: Math.min(plan.validation.openAiCallsUsed, maxOpenAiCalls),
    },
  };
}

async function createLocalReelPlan(
  input: ReelPlanRequest,
): Promise<ReelPlanResult> {
  const normalized = normalizeTranscriptForPlanner({
    transcript: input.transcript,
    words: input.words,
    segments: input.timestampSegments,
  });
  const language = input.languageHint === 'english' && !normalized.sourceHadHindiUrduScript ? 'english' : normalized.languageHint || input.languageHint || detectLanguage(normalized.transcript);
  const durationSeconds = getSafeDuration(input.durationSeconds, normalized.words, normalized.segments, normalized.transcript);
  const segments = getTimedSegments({
    transcript: normalized.transcript,
    words: normalized.words,
    segments: normalized.segments,
    durationSeconds,
  });
  const templateName = getTemplateName(input.template);
  const fallbackScriptDetails = input.scriptDetails || extractScriptDetails({
    transcript: normalized.transcript,
    topicTitle: input.topicTitle || input.topic,
    segments,
  });
  const scriptDetails = fallbackScriptDetails;
  const overlayTimeline = attachOverlayWords(
    buildOverlayTimeline(segments, input, language, scriptDetails, templateName),
    normalized.words,
  );
  const mediaType = input.mediaType || (templateName === 'HANDWRITTEN_NOTES' ? 'audio' : 'video');
  const visualMode = templateName === 'HANDWRITTEN_NOTES'
    ? 'notes' as const
    : templateName === 'VIDEO_CAPTION'
      ? 'videoCaption' as const
      : templateName === 'IMAGE_STORY'
        ? 'imageStory' as const
      : 'videoExplainer' as const;
  const primaryFocus = templateName === 'HANDWRITTEN_NOTES'
    ? 'notesCanvas' as const
    : templateName === 'VIDEO_CAPTION'
      ? 'captions' as const
      : templateName === 'IMAGE_STORY'
        ? 'images' as const
      : 'topVisual' as const;
  const captions = templateName === 'VIDEO_CAPTION'
    ? buildVideoCaptionPlan({
        words: normalized.words,
        segments: normalized.segments,
        durationSeconds,
        stylePreset: getCaptionStylePreset(input.design, input.visualMode),
      })
    : segments.map((segment) => ({
        start: roundTime(segment.start),
        end: roundTime(Math.min(durationSeconds, segment.end)),
        text: trimWords(segment.text, 18),
      }));
  const timeline = overlayTimeline.map((item, index) => ({
    id: item.id,
    start: item.start,
    end: item.end,
    purpose: index === 0 ? 'hook' as const : index === overlayTimeline.length - 1 ? 'cta' as const : index % 3 === 0 ? 'proof' as const : 'explain' as const,
    script: [item.text, item.body].filter(Boolean).join('. '),
    density: 'medium' as const,
    visualEnergy: getVisualEnergy(item.type, index, overlayTimeline.length),
    speechImportance: index === 0 ? 0.9 : 0.7,
    sceneComplexity: getSceneComplexity(item.type),
    visualMode,
    primaryFocus,
    secondarySupport: ['titleCard'] as Array<'titleCard'>,
  }));
  const topicTitle = cleanTitle(input.topicTitle || input.topic || deriveTopicTitle(segments, normalized.transcript));
  const imageStoryProps = templateName === 'IMAGE_STORY'
    ? buildImageStoryProps({
        input,
        segments,
        durationSeconds,
        language,
        topicTitle,
        scriptDetails,
      })
    : undefined;

  return {
    provider: 'local',
    model: templateName === 'HANDWRITTEN_NOTES'
      ? 'handwritten-notes-planner'
      : templateName === 'VIDEO_CAPTION'
        ? 'video-caption-planner'
        : templateName === 'IMAGE_STORY'
          ? 'image-story-planner'
          : 'video-explainer-planner',
    template: templateName,
    templateName,
    analysis: {
      durationSeconds,
      speechDensity: estimateSpeechDensity(normalized.transcript, durationSeconds),
      hookStrength: estimateHookStrength(segments[0]?.text || normalized.transcript),
      language,
    },
    timeline,
    assets: {
      suggested: buildSuggestedAssets(scriptDetails, templateName),
      required: templateName === 'HANDWRITTEN_NOTES'
        ? ['uploaded voiceover']
        : templateName === 'IMAGE_STORY'
          ? ['at least one uploaded or selected image']
          : ['uploaded primary video'],
      avoid: templateName === 'HANDWRITTEN_NOTES'
        ? ['prewritten notebook poster', 'watermark/logo overlays', 'repeated same text blocks']
        : templateName === 'IMAGE_STORY'
          ? ['static slideshow', 'full subtitles', 'explainer cards', 'placeholder labels', 'stretched images']
          : ['watermark/logo overlays', 'duplicate subtitles', 'crowded bottom text'],
    },
    scriptDetails,
    renderProps: {
      brand: 'itnavideo',
      topicTitle,
      design: input.design,
      templateName,
      scriptDetails,
      mediaType,
      mediaFit: templateName === 'HANDWRITTEN_NOTES'
        ? 'notes'
        : templateName === 'VIDEO_CAPTION'
          ? 'videoCaption'
          : templateName === 'IMAGE_STORY'
            ? 'imageStory'
            : 'videoExplainer',
      durationSeconds,
      overlayTimeline,
      captions,
      ...(templateName === 'VIDEO_CAPTION'
        ? {
            captionPlan: buildCaptionPlan(captions),
            videoStyle: normalizeVideoCaptionStyle(undefined),
            safeZones: normalizeSafeZones(undefined),
          }
        : {}),
      ...(imageStoryProps || {}),
    },
    validation: {
      status: 'complete',
      repairable: true,
      warnings: [],
      notes: [
        templateName === 'HANDWRITTEN_NOTES'
          ? 'Handwritten Notes plan created from timestamp segments.'
          : templateName === 'VIDEO_CAPTION'
            ? 'Video Caption plan created from timestamp segments and word timings.'
            : templateName === 'IMAGE_STORY'
              ? 'Image Story plan created as image-led cinematic story beats.'
          : 'Video Explainer plan created from timestamp segments.',
        scriptDetails.planningSource === 'ai'
          ? `AI Script Details read the full ${scriptDetails.wordCount || 0}-word script before JSON planning.`
          : `Rule-based Script Details read the full ${scriptDetails.wordCount || 0}-word script before JSON planning.`,
        scriptDetails.imageUsagePolicy
          ? `Image policy: use ${scriptDetails.imageUsagePolicy.minImages}-${scriptDetails.imageUsagePolicy.maxImages} images, recommended ${scriptDetails.imageUsagePolicy.recommendedImages}.`
          : 'Image policy was not provided.',
        scriptDetails.imageSelectionPlan?.length
          ? `AI selected ${scriptDetails.imageSelectionPlan.length} semantic image needs before render planning.`
          : 'No semantic image selection plan was provided.',
        language === 'hinglish'
          ? templateName === 'HANDWRITTEN_NOTES'
            ? 'Hindi/Urdu timestamp segments stay source-accurate for transcription; Handwritten Notes final text uses English keywords plus Hinglish support lines.'
            : templateName === 'VIDEO_EXPLAINER'
              ? 'Hindi/Urdu timestamp segments stay source-accurate; Video Explainer final text uses official English keywords plus clean Hinglish support lines.'
              : 'Timestamp segments were normalized to Clean Hinglish roman text.'
          : 'Timestamp segments were kept in clean English text.',
        normalized.words?.length
          ? `Word-level sync enabled with ${normalized.words.length} timed transcript words.`
          : templateName === 'VIDEO_CAPTION'
            ? 'Word timings unavailable; VIDEO_CAPTION requires timestamp segments for phrase reveal.'
            : 'Word-level sync unavailable; renderer will use duration-based pacing.',
        'Template uses lightweight visual direction without forcing fixed asset rules.',
      ],
      renderAllowed: true,
      qualityScore: 92,
      qualityBand: 'professional',
      qualityChecks: [
        templateName === 'HANDWRITTEN_NOTES' ? 'One continuous handwritten notes canvas.' : templateName === 'VIDEO_CAPTION' ? 'One continuous captioned video.' : templateName === 'IMAGE_STORY' ? 'One continuous image-led cinematic story.' : 'One continuous video scene.',
        templateName === 'HANDWRITTEN_NOTES'
          ? 'Uploaded voiceover drives full-screen handwritten notes.'
          : templateName === 'VIDEO_CAPTION'
            ? 'Uploaded video stays full-screen while timed captions are rendered above safe zones.'
            : templateName === 'IMAGE_STORY'
              ? 'One primary image drives each scene with subtle cinematic motion.'
          : 'Uploaded video remains in the top visual container as the primary story.',
        templateName === 'HANDWRITTEN_NOTES'
          ? 'Handwritten Notes layout uses short written points without prewritten background text.'
          : templateName === 'VIDEO_CAPTION'
            ? 'Captions use short lines with word-level highlighting when transcript timings are available.'
            : templateName === 'IMAGE_STORY'
              ? 'Text is minimal and never becomes full subtitles or explainer cards.'
          : 'Bottom layout uses a large hook and short explanation without duplicate subtitles.',
      ],
      qualityFindings: [],
      pipeline: [
        {
          step: 'Transcript',
          status: 'complete',
          detail: templateName === 'HANDWRITTEN_NOTES'
            ? 'Audio/video transcript preserved for source accuracy before visible-note language conversion.'
            : 'Audio/video transcript cleaned for display.',
        },
        {
          step: templateName === 'HANDWRITTEN_NOTES' ? 'CreativeDirector' : 'Script Details',
          status: 'complete',
          detail: templateName === 'HANDWRITTEN_NOTES'
            ? scriptDetails.planningSource === 'ai'
              ? `AI directed ${scriptDetails.videoUsePlan?.length || 0} timed note actions from the ${scriptDetails.wordCount || 0}-word script.`
              : `Rule-based director extracted ${scriptDetails.detailBlocks.length} note blocks from ${scriptDetails.wordCount || 0} words.`
            : scriptDetails.planningSource === 'ai'
              ? `AI analyzed ${scriptDetails.wordCount || 0} words and planned ${scriptDetails.videoUsePlan?.length || 0} video-use moments.`
              : `Extracted ${scriptDetails.detailBlocks.length} structured detail blocks from ${scriptDetails.wordCount || 0} words.`,
        },
        {
          step: templateName === 'HANDWRITTEN_NOTES' ? 'ManagerChecklist' : 'Timing',
          status: 'complete',
          detail: templateName === 'HANDWRITTEN_NOTES'
            ? `Checked audio-matched note timing before the ${durationSeconds}s render.`
            : `Planned ${durationSeconds}s render window.`,
        },
        {
          step: templateName === 'HANDWRITTEN_NOTES' ? 'Remotion Props' : 'JSON',
          status: 'complete',
          detail: normalized.words?.length
            ? 'Created overlayTimeline with word-level timing metadata.'
            : 'Created overlayTimeline and captions render props.',
        },
      ],
      openAiCallsUsed: scriptDetails.planningSource === 'ai' ? 1 : 0,
    },
  };
}

function buildVideoCaptionPlan({
  words,
  segments,
  durationSeconds,
  stylePreset,
}: {
  words?: ReelWord[];
  segments?: ReelTranscriptSegment[];
  durationSeconds: number;
  stylePreset: 'boldCreator' | 'cleanSubtitle' | 'podcast' | 'screenRecord' | 'productDemo';
}): ReelPlanResult['renderProps']['captions'] {
  const timedWords = (words || [])
    .filter((word) => word.word && Number.isFinite(word.start) && Number.isFinite(word.end) && word.end > word.start && word.start < durationSeconds)
    .map((word) => ({
      word: cleanCaptionText(word.word).slice(0, 40),
      start: roundTime(clampPlanNumber(word.start, 0, durationSeconds)),
      end: roundTime(clampPlanNumber(word.end, word.start + 0.02, durationSeconds)),
    }))
    .filter((word) => word.word && word.end > word.start);

  if (timedWords.length) {
    return dedupeCaptions(chunkWords(timedWords, 10).map((chunk, index) => {
      const start = chunk[0].start;
      const end = Math.min(durationSeconds, Math.max(chunk.at(-1)?.end || start + 0.6, start + 0.6));
      const text = cleanCaptionText(chunk.map((word) => word.word).join(' '));
      const lines = breakCaptionLines(text);
      const wordLineMap = mapWordsToLines(lines);
      return {
        id: `caption-${index + 1}`,
        start: roundTime(start),
        end: roundTime(end),
        text,
        lines,
        words: chunk.map((word, wordIndex) => ({
          word: word.word,
          start: roundTime(Math.max(0, word.start - start)),
          end: roundTime(Math.max(0.02, word.end - start)),
          lineIndex: wordLineMap[wordIndex]?.lineIndex || 0,
          wordIndex: wordLineMap[wordIndex]?.wordIndex || wordIndex,
        })),
        mode: 'wordHighlight' as const,
        stylePreset,
      };
    }));
  }

  const timedSegments = (segments || [])
    .filter((segment) => segment.text && Number.isFinite(segment.start) && Number.isFinite(segment.end) && segment.end > segment.start && segment.start < durationSeconds)
    .map((segment) => ({
      start: roundTime(clampPlanNumber(segment.start, 0, durationSeconds)),
      end: roundTime(clampPlanNumber(segment.end, segment.start + 0.6, durationSeconds)),
      text: cleanCaptionText(segment.text),
    }))
    .filter((segment) => segment.text && segment.end > segment.start);

  return dedupeCaptions(timedSegments.flatMap((segment, segmentIndex) => {
    const chunks = chunkCaptionText(segment.text, 12);
    if (!chunks.length) return [];
    const duration = Math.max(0.6, segment.end - segment.start);
    return chunks.map((chunk, chunkIndex) => {
      const start = segment.start + (duration * chunkIndex) / chunks.length;
      const end = segment.start + (duration * (chunkIndex + 1)) / chunks.length;
      const safeEnd = Math.min(durationSeconds, Math.max(end, start + 0.6));
      return {
        id: `caption-${segmentIndex + 1}-${chunkIndex + 1}`,
        start: roundTime(start),
        end: roundTime(safeEnd),
        text: chunk,
        lines: breakCaptionLines(chunk),
        mode: 'phraseReveal' as const,
        stylePreset,
      };
    });
  }));
}

function repairCaptionsForTemplate(
  captions: ReelPlanResult['renderProps']['captions'],
  durationSeconds: number,
  templateName: ReelTemplateName,
  warnings: string[],
): ReelPlanResult['renderProps']['captions'] {
  const minCaptionSeconds = templateName === 'VIDEO_CAPTION' ? 0.6 : 0.2;
  const repaired = (captions || [])
    .map((caption, index) => {
      const start = roundTime(clampPlanNumber(Number(caption.start), 0, durationSeconds));
      const end = roundTime(clampPlanNumber(Number(caption.end), start + minCaptionSeconds, durationSeconds));
      const text = cleanCaptionText(caption.text).slice(0, templateName === 'VIDEO_CAPTION' ? 120 : 140);
      if (!text || end <= start) return null;
      if (templateName === 'VIDEO_CAPTION' && isPlaceholderCaption(text)) {
        warnings.push('Placeholder caption text was removed before render.');
        return null;
      }
      const lines = templateName === 'VIDEO_CAPTION'
        ? breakCaptionLines(text)
        : caption.lines?.map((line) => cleanCaptionText(line).slice(0, 56)).filter(Boolean).slice(0, 2);
      const words = templateName === 'VIDEO_CAPTION'
        ? normalizeCaptionWords(caption.words, end - start)
        : caption.words;
      if (templateName === 'VIDEO_CAPTION' && words?.some((word) => word.start < 0 || word.end > end - start + 0.1)) {
        warnings.push('Caption word timing outside its phrase was repaired before render.');
      }
      return {
        ...caption,
        id: 'id' in caption ? String(caption.id || `caption-${index + 1}`) : `caption-${index + 1}`,
        start,
        end,
        text,
        lines,
        words,
        mode: templateName === 'VIDEO_CAPTION'
          ? words?.length ? 'wordHighlight' as const : caption.mode === 'segmentCaption' ? 'segmentCaption' as const : 'phraseReveal' as const
          : caption.mode,
        stylePreset: templateName === 'VIDEO_CAPTION'
          ? normalizeCaptionStyle(caption.stylePreset)
          : caption.stylePreset,
      };
    })
    .filter((caption): caption is NonNullable<typeof caption> => Boolean(caption));
  return repairCaptionOverlaps(dedupeCaptions(repaired), minCaptionSeconds, warnings);
}

function normalizeCaptionWords(
  words: ReelPlanResult['renderProps']['captions'][number]['words'],
  captionDuration: number,
) {
  const cleaned = (words || [])
    .map((word, index) => ({
      word: cleanCaptionText(word.word).slice(0, 40),
      start: roundTime(clampPlanNumber(Number(word.start), 0, captionDuration)),
      end: roundTime(clampPlanNumber(Number(word.end), Number(word.start) + 0.02, captionDuration)),
      lineIndex: Number.isFinite(word.lineIndex) ? clampPlanNumber(Number(word.lineIndex), 0, 1) : undefined,
      wordIndex: Number.isFinite(word.wordIndex) ? clampPlanNumber(Number(word.wordIndex), 0, 14) : index,
    }))
    .filter((word) => word.word && word.end > word.start);
  return cleaned.length ? cleaned : undefined;
}

function dedupeCaptions(captions: ReelPlanResult['renderProps']['captions']) {
  const seen = new Set<string>();
  return captions.filter((caption) => {
    const key = cleanCaptionText(caption.text).toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function repairCaptionOverlaps(
  captions: ReelPlanResult['renderProps']['captions'],
  minCaptionSeconds: number,
  warnings: string[],
) {
  let previousEnd = 0;
  return captions
    .slice()
    .sort((a, b) => a.start - b.start)
    .map((caption) => {
      if (caption.start >= previousEnd - 0.05) {
        previousEnd = caption.end;
        return caption;
      }
      const shiftedStart = roundTime(previousEnd);
      if (caption.end - shiftedStart < minCaptionSeconds) {
        warnings.push('Overlapping caption timing was removed before render.');
        return null;
      }
      previousEnd = caption.end;
      warnings.push('Overlapping caption timing was repaired before render.');
      return {...caption, start: shiftedStart};
    })
    .filter((caption): caption is ReelPlanResult['renderProps']['captions'][number] => Boolean(caption));
}

function buildCaptionPlan(captions: ReelPlanResult['renderProps']['captions']): NonNullable<ReelPlanResult['renderProps']['captionPlan']> {
  const mode = captions.some((caption) => caption.mode === 'wordHighlight')
    ? 'wordHighlight'
    : captions.some((caption) => caption.mode === 'segmentCaption')
      ? 'segmentCaption'
      : 'phraseReveal';
  return {
    mode,
    position: 'bottomSafe',
    avoidArea: 'none',
    captions,
  };
}

function normalizeVideoCaptionStyle(value: ReelPlanResult['renderProps']['videoStyle'] | undefined): NonNullable<ReelPlanResult['renderProps']['videoStyle']> {
  return {
    fit: value?.fit === 'contain' ? 'contain' : 'cover',
    cropMode: value?.cropMode === 'faceSafe' || value?.cropMode === 'screenSafe' ? value.cropMode : 'center',
    backgroundBlur: Boolean(value?.backgroundBlur),
  };
}

function normalizeSafeZones(value: ReelPlanResult['renderProps']['safeZones'] | undefined): NonNullable<ReelPlanResult['renderProps']['safeZones']> {
  return {
    top: clampPlanNumber(Number(value?.top), 0, 320) || 120,
    bottom: clampPlanNumber(Number(value?.bottom), 0, 520) || 340,
    left: clampPlanNumber(Number(value?.left), 0, 240) || 72,
    right: clampPlanNumber(Number(value?.right), 0, 240) || 140,
  };
}

function buildImageStoryProps({
  input,
  segments,
  durationSeconds,
  language,
  topicTitle,
  scriptDetails,
}: {
  input: ReelPlanRequest;
  segments: Array<{start: number; end: number; text: string}>;
  durationSeconds: number;
  language: 'english' | 'hinglish';
  topicTitle?: string;
  scriptDetails: ScriptDetails;
}): Pick<ReelPlanResult['renderProps'], 'source' | 'images' | 'storyPlan' | 'safeZones' | 'imageSources' | 'imageScenes'> {
  const imageSources = collectImageSources(input);
  const images = imageSources.map<ReelImageStoryImage>((src, index) => ({
    id: `image-${index + 1}`,
    src,
    source: src.includes('fallback') ? 'fallback' : 'uploaded',
    alt: sanitizeStoryText(topicTitle || input.topic || `Image ${index + 1}`),
    safeCrop: {
      focusX: 0.5,
      focusY: 0.45,
      avoidTextZone: 'bottom',
    },
  }));
  const mode = input.mediaType === 'audio'
    ? 'audioImageStory'
    : images.length > 1
      ? 'multiImage'
      : input.mediaType === 'image'
        ? 'imageOnlyStory'
        : 'singleImage';
  const beatSource = segments.length && mode === 'audioImageStory'
    ? segments
    : buildImageOnlyBeats(topicTitle || input.topic || scriptDetails.topic || 'Image story', durationSeconds);
  const scenes = beatSource.slice(0, 12).map<ReelImageStoryScene>((segment, index) => {
    const image = images[index % Math.max(1, images.length)];
    const role = index === 0 ? 'hero' : index === beatSource.length - 1 ? 'ending' : index % 3 === 0 ? 'proof' : 'detail';
    const overlayText = limitStoryWords(segment.text || topicTitle || 'Story beat', index === 0 ? 7 : 6);
    return {
      id: `image-scene-${index + 1}`,
      start: roundTime(clampPlanNumber(segment.start, 0, durationSeconds)),
      end: roundTime(clampPlanNumber(segment.end, segment.start + 1, durationSeconds)),
      imageId: image?.id || 'image-1',
      imageRole: role,
      beatText: overlayText,
      label: role === 'hero' ? 'Story' : role === 'ending' ? 'Final' : undefined,
      title: overlayText,
      motion: defaultImageStoryMotion(index, beatSource.length),
      textOverlay: {
        enabled: Boolean(overlayText),
        text: overlayText,
        position: index === 0 ? 'centerSoft' : 'lowerThird',
        maxLines: overlayText.split(/\s+/).length > 4 ? 2 : 1,
        style: role === 'hero' ? 'punchLine' : 'minimalTitle',
      },
      transition: {
        in: index === 0 ? 'fade' : 'blurReveal',
        out: index === beatSource.length - 1 ? 'fade' : 'cut',
      },
    };
  }).filter((scene) => scene.end > scene.start);
  const repairedScenes = repairImageStorySceneList(scenes, images);

  return {
    source: {
      mode,
      topic: sanitizeStoryText(topicTitle || input.topic || scriptDetails.topic || '').slice(0, 120) || undefined,
      prompt: sanitizeStoryText(input.topic || topicTitle || scriptDetails.summary || '').slice(0, 240) || undefined,
    },
    images,
    storyPlan: {
      languageMode: language === 'hinglish' ? 'roman_hinglish' : 'english',
      stylePreset: getImageStoryStylePreset(input.design, input.topic || topicTitle || scriptDetails.topic),
      scenes: repairedScenes,
    },
    safeZones: normalizeSafeZones(undefined),
    imageSources: images.map((image) => image.src),
    imageScenes: repairedScenes.map((scene) => ({
      id: scene.id,
      start: scene.start,
      end: scene.end,
      imageSrc: images.find((image) => image.id === scene.imageId)?.src,
      imageFit: getImageFitForStyle(input.design),
      title: scene.textOverlay?.text || scene.title || scene.beatText || 'Story beat',
      body: '',
      accentWord: pickAccentWord(scene.textOverlay?.text || scene.title || '', topicTitle),
      label: scene.label,
      tone: scene.imageRole === 'ending' ? 'cta' : scene.imageRole === 'hero' ? 'hook' : 'point',
    })),
  };
}

function repairImageStoryProps(
  props: ReelPlanResult['renderProps'],
  durationSeconds: number,
  warnings: string[],
): Pick<ReelPlanResult['renderProps'], 'source' | 'images' | 'storyPlan' | 'safeZones' | 'imageSources' | 'imageScenes'> {
  const sourceImages: ReelImageStoryImage[] = props.images?.length ? props.images : (props.imageSources || []).map((src, index) => ({
    id: `image-${index + 1}`,
    src,
    source: 'uploaded' as const,
  }));
  const images = sourceImages
    .map((image, index) => ({
      ...image,
      id: sanitizeId(image.id || `image-${index + 1}`),
      src: String(image.src || '').trim(),
      source: image.source === 'selectedAsset' || image.source === 'generated' || image.source === 'fallback' ? image.source : 'uploaded' as const,
      alt: sanitizeStoryText(image.alt || '').slice(0, 120) || undefined,
      category: sanitizeStoryText(image.category || '').slice(0, 48) || undefined,
      safeCrop: image.safeCrop ? {
        focusX: clampPlanNumber(Number(image.safeCrop.focusX), 0, 1),
        focusY: clampPlanNumber(Number(image.safeCrop.focusY), 0, 1),
        avoidTextZone: image.safeCrop.avoidTextZone === 'top' || image.safeCrop.avoidTextZone === 'center' || image.safeCrop.avoidTextZone === 'none' ? image.safeCrop.avoidTextZone : 'bottom' as const,
      } : {focusX: 0.5, focusY: 0.45, avoidTextZone: 'bottom' as const},
    }))
    .filter((image) => image.src && !isPlaceholderImageSource(image.src))
    .slice(0, 24);

  if (!images.length) warnings.push('Image Story has no usable image sources.');
  const scenes = repairImageStorySceneList((props.storyPlan?.scenes || []).map((scene, index) => ({
    id: sanitizeId(scene.id || `image-scene-${index + 1}`),
    start: roundTime(clampPlanNumber(Number(scene.start), 0, durationSeconds)),
    end: roundTime(clampPlanNumber(Number(scene.end), Number(scene.start) + 0.8, durationSeconds)),
    imageId: images.some((image) => image.id === scene.imageId) ? scene.imageId : images[index % Math.max(1, images.length)]?.id || 'image-1',
    imageRole: normalizeImageRole(scene.imageRole, index, props.storyPlan?.scenes.length || 1),
    beatText: limitStoryWords(scene.beatText || scene.title || scene.textOverlay?.text || '', 7),
    label: isPlaceholderStoryText(scene.label || '') ? undefined : limitStoryWords(scene.label || '', 3),
    title: isPlaceholderStoryText(scene.title || '') ? undefined : limitStoryWords(scene.title || scene.beatText || scene.textOverlay?.text || '', 7),
    motion: normalizeImageMotion(scene.motion, index, props.storyPlan?.scenes.length || 1),
    textOverlay: normalizeImageTextOverlay(scene.textOverlay, scene.title || scene.beatText),
    transition: {
      in: (scene.transition?.in === 'cut' || scene.transition?.in === 'slide' || scene.transition?.in === 'blurReveal' ? scene.transition.in : 'fade') as NonNullable<ReelImageStoryScene['transition']>['in'],
      out: (scene.transition?.out === 'cut' || scene.transition?.out === 'blur' ? scene.transition.out : 'fade') as NonNullable<ReelImageStoryScene['transition']>['out'],
    },
  })).filter((scene) => scene.end > scene.start), images);

  return {
    source: {
      mode: props.source?.mode === 'multiImage' || props.source?.mode === 'audioImageStory' || props.source?.mode === 'imageOnlyStory' ? props.source.mode : images.length > 1 ? 'multiImage' : 'singleImage',
      topic: sanitizeStoryText(props.source?.topic || props.topicTitle || '').slice(0, 120) || undefined,
      prompt: sanitizeStoryText(props.source?.prompt || props.topicTitle || '').slice(0, 240) || undefined,
    },
    images,
    storyPlan: {
      languageMode: props.storyPlan?.languageMode === 'roman_hinglish' ? 'roman_hinglish' : 'english',
      stylePreset: props.storyPlan?.stylePreset || 'cinematic',
      scenes,
    },
    safeZones: normalizeSafeZones(props.safeZones),
    imageSources: images.map((image) => image.src),
    imageScenes: scenes.map((scene) => ({
      id: scene.id,
      start: scene.start,
      end: scene.end,
      imageSrc: images.find((image) => image.id === scene.imageId)?.src,
      imageFit: 'smart' as const,
      title: scene.textOverlay?.text || scene.title || scene.beatText || 'Story beat',
      body: '',
      accentWord: pickAccentWord(scene.textOverlay?.text || scene.title || '', props.topicTitle),
      label: scene.label,
      tone: scene.imageRole === 'ending' ? 'cta' as const : scene.imageRole === 'hero' ? 'hook' as const : 'point' as const,
    })),
  };
}

function collectImageSources(input: ReelPlanRequest) {
  const rawSources = Object.values(input.selectedAssets || {}).flat()
    .filter((value) => /\.(png|jpe?g|webp|gif)(?:[?#].*)?$/i.test(value) || /^https?:/i.test(value) || value.startsWith('/'));
  return uniqueStrings(rawSources).slice(0, 24);
}

function buildImageOnlyBeats(topic: string, durationSeconds: number) {
  const clean = sanitizeStoryText(topic) || 'Image story';
  const beats = [
    clean,
    'A closer detail',
    'The key moment',
    'Final frame',
  ];
  const sceneCount = Math.min(4, Math.max(1, Math.ceil(durationSeconds / 4)));
  const sceneDuration = durationSeconds / sceneCount;
  return Array.from({length: sceneCount}).map((_, index) => ({
    start: roundTime(index * sceneDuration),
    end: roundTime(Math.min(durationSeconds, (index + 1) * sceneDuration)),
    text: beats[index] || clean,
  }));
}

function repairImageStorySceneList(scenes: ReelImageStoryScene[], images: ReelImageStoryImage[]) {
  let previousImageId = '';
  let repeatCount = 0;
  return scenes.map((scene, index) => {
    let imageId = images.some((image) => image.id === scene.imageId) ? scene.imageId : images[index % Math.max(1, images.length)]?.id || scene.imageId;
    if (images.length > 1) {
      repeatCount = imageId === previousImageId ? repeatCount + 1 : 1;
      if (repeatCount > 2) {
        imageId = images[index % images.length].id;
        repeatCount = 1;
      }
      previousImageId = imageId;
    }
    return {
      ...scene,
      imageId,
      motion: normalizeImageMotion(scene.motion, index, scenes.length),
      textOverlay: normalizeImageTextOverlay(scene.textOverlay, scene.title || scene.beatText),
    };
  });
}

function defaultImageStoryMotion(index: number, total: number): ReelImageStoryScene['motion'] {
  const types: ReelImageStoryMotionType[] = ['slowZoomIn', 'panRight', 'parallax', 'panLeft', 'pushIn', 'panUp'];
  return {
    type: index === 0 ? 'slowZoomIn' : index === total - 1 ? 'slowZoomOut' : types[index % types.length],
    intensity: index === 0 || index === total - 1 ? 'low' : 'medium',
    focusX: 0.5,
    focusY: 0.45,
  };
}

function normalizeImageMotion(value: ReelImageStoryScene['motion'] | undefined, index: number, total: number): ReelImageStoryScene['motion'] {
  const fallback = defaultImageStoryMotion(index, total);
  const allowed = new Set<ReelImageStoryMotionType>(['slowZoomIn', 'slowZoomOut', 'panLeft', 'panRight', 'panUp', 'panDown', 'parallax', 'pushIn', 'reveal']);
  return {
    type: value?.type && allowed.has(value.type) ? value.type : fallback.type,
    intensity: value?.intensity === 'low' || value?.intensity === 'medium' ? value.intensity : fallback.intensity,
    focusX: clampPlanNumber(Number(value?.focusX ?? fallback.focusX), 0, 1),
    focusY: clampPlanNumber(Number(value?.focusY ?? fallback.focusY), 0, 1),
  };
}

function normalizeImageTextOverlay(value: ReelImageStoryScene['textOverlay'] | undefined, fallbackText?: string): ReelImageStoryScene['textOverlay'] {
  const text = isPlaceholderStoryText(value?.text || fallbackText || '') ? '' : limitStoryWords(value?.text || fallbackText || '', 7);
  return {
    enabled: Boolean(text) && value?.position !== 'none',
    text,
    position: value?.position === 'topSafe' || value?.position === 'centerSoft' || value?.position === 'none' ? value.position : 'lowerThird',
    maxLines: text.split(/\s+/).length > 4 ? 2 : 1,
    style: value?.style === 'smallLabel' || value?.style === 'productTag' || value?.style === 'minimalTitle' ? value.style : 'punchLine',
  };
}

function normalizeImageRole(value: unknown, index: number, total: number): ReelImageStoryScene['imageRole'] {
  if (value === 'hero' || value === 'detail' || value === 'proof' || value === 'transition' || value === 'ending') return value;
  if (index === 0) return 'hero';
  if (index === total - 1) return 'ending';
  return index % 3 === 0 ? 'proof' : 'detail';
}

function sanitizeStoryText(input: unknown) {
  return cleanDisplayText(String(input || '')).replace(/\.\.\.$/, '').trim();
}

function limitStoryWords(value: unknown, maxWords: number) {
  return sanitizeStoryText(value).split(/\s+/).filter(Boolean).slice(0, maxWords).join(' ');
}

function isPlaceholderStoryText(value: string) {
  return /^(image brief|visual story|scene\s*\d+|key point|important|image story|story beat)$/i.test(sanitizeStoryText(value));
}

function isPlaceholderImageSource(value: string) {
  const source = String(value || '').trim();
  return /^(about:blank|placeholder|none)$/i.test(source) || !/^(https?:|data:image\/|blob:|\/)/i.test(source);
}

function getImageStoryStylePreset(design?: string, topic?: string): ReelImageStoryStylePreset {
  const source = `${design || ''} ${topic || ''}`.toLowerCase();
  if (/product|shop|commerce|sale/.test(source)) return 'product';
  if (/study|education|exam|learn|school|college/.test(source)) return 'education';
  if (/motivat|success|mindset|story/.test(source)) return 'motivation';
  if (/doc|news|report|history/.test(source)) return 'documentary';
  return 'cinematic';
}

function getImageFitForStyle(design?: string): 'cover' | 'contain' | 'smart' {
  return /product|screen|document|screenshot/i.test(design || '') ? 'contain' : 'smart';
}

function sanitizeId(value: string) {
  return cleanDisplayText(value).replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 48) || 'item';
}

function isPlaceholderCaption(value: string) {
  return /^(important point|key idea|visual brief|caption|subtitle|main point|upload video|get clean captions|ready for reels)$/i.test(cleanCaptionText(value));
}

function chunkCaptionText(value: string, maxWords: number) {
  const words = cleanCaptionText(value).split(/\s+/).filter(Boolean);
  const chunks = [];
  for (let index = 0; index < words.length; index += maxWords) {
    const text = words.slice(index, index + maxWords).join(' ');
    if (text) chunks.push(text);
  }
  return chunks;
}

function breakCaptionLines(value: string) {
  const words = cleanCaptionText(value).split(/\s+/).filter(Boolean).slice(0, 14);
  if (words.length <= 7) return [words.join(' ')];
  const midpoint = Math.ceil(words.length / 2);
  return [words.slice(0, midpoint).join(' '), words.slice(midpoint).join(' ')].filter(Boolean);
}

function mapWordsToLines(lines: string[]) {
  return lines.flatMap((line, lineIndex) =>
    line.split(/\s+/).filter(Boolean).map((_, wordIndex) => ({lineIndex, wordIndex})),
  );
}

function cleanCaptionText(value: unknown) {
  return cleanDisplayText(String(value || '')).replace(/\.\.\.$/, '').trim();
}

function getCaptionStylePreset(design?: string, visualMode?: string): 'boldCreator' | 'cleanSubtitle' | 'podcast' | 'screenRecord' | 'productDemo' {
  const source = `${design || ''} ${visualMode || ''}`.toLowerCase();
  if (/screen|demo|tutorial|record/.test(source)) return 'screenRecord';
  if (/product|shop|commerce/.test(source)) return 'productDemo';
  if (/podcast|talk|interview/.test(source)) return 'podcast';
  if (/clean|minimal/.test(source)) return 'cleanSubtitle';
  return 'boldCreator';
}

function normalizeCaptionStyle(value: unknown): 'boldCreator' | 'cleanSubtitle' | 'podcast' | 'screenRecord' | 'productDemo' {
  if (value === 'boldCreator' || value === 'cleanSubtitle' || value === 'podcast' || value === 'screenRecord' || value === 'productDemo') return value;
  return 'boldCreator';
}

function attachOverlayWords<T extends {start: number; end: number}>(
  overlays: T[],
  words?: ReelWord[],
): Array<T & {words?: ReelWord[]}> {
  if (!words?.length) return overlays;
  return overlays.map((overlay) => {
    const overlayWords = words
      .filter((word) => word.end > overlay.start && word.start < overlay.end)
      .map((word) => ({
        word: word.word,
        start: roundTime(Math.max(0, word.start - overlay.start)),
        end: roundTime(Math.min(overlay.end, word.end) - overlay.start),
      }))
      .filter((word) => word.word && word.end > word.start);
    return overlayWords.length ? {...overlay, words: overlayWords} : overlay;
  });
}

function getTemplateName(value?: string): ReelTemplateName {
  const normalized = String(value || '').toLowerCase();
  if (normalized.includes('handwriting') || normalized.includes('notes')) return 'HANDWRITTEN_NOTES';
  if (normalized.includes('caption') || normalized.includes('subtitle')) return 'VIDEO_CAPTION';
  if (normalized.includes('image') || normalized.includes('photo') || normalized.includes('story')) return 'IMAGE_STORY';
  return 'VIDEO_EXPLAINER';
}

function getSafeDuration(
  requestedDuration: unknown,
  words: ReelWord[] | undefined,
  segments: ReelTranscriptSegment[] | undefined,
  transcript: string,
) {
  const explicit = Number(requestedDuration);
  if (Number.isFinite(explicit) && explicit > 0) return roundTime(Math.min(MAX_SECONDS, explicit));
  const lastSegment = segments?.at(-1);
  if (lastSegment?.end) return roundTime(Math.min(MAX_SECONDS, lastSegment.end));
  const lastWord = words?.at(-1);
  if (lastWord?.end) return roundTime(Math.min(MAX_SECONDS, lastWord.end));
  const estimated = Math.max(8, transcript.split(/\s+/).filter(Boolean).length / 2.4);
  return roundTime(Math.min(MAX_SECONDS, estimated));
}

function getTimedSegments({
  transcript,
  words,
  segments,
  durationSeconds,
}: {
  transcript: string;
  words?: ReelWord[];
  segments?: ReelTranscriptSegment[];
  durationSeconds: number;
}) {
  const fromSegments = (segments || [])
    .map((segment) => ({
      start: roundTime(Math.max(0, segment.start)),
      end: roundTime(Math.min(durationSeconds, Math.max(segment.start + 0.2, segment.end))),
      text: cleanDisplayText(segment.text),
    }))
    .filter((segment) => segment.text && segment.start < durationSeconds && segment.end > segment.start);

  if (fromSegments.length) return fromSegments;

  if (words?.length) {
    const chunks = chunkWords(words.filter((word) => word.start < durationSeconds), 8);
    if (chunks.length) {
      return chunks.map((chunk) => ({
        start: roundTime(chunk[0].start),
        end: roundTime(Math.min(durationSeconds, chunk.at(-1)?.end || chunk[0].end + 1)),
        text: cleanDisplayText(chunk.map((word) => word.word).join(' ')),
      }));
    }
  }

  const plainWords = cleanDisplayText(transcript).split(/\s+/).filter(Boolean);
  const total = Math.max(1, plainWords.length);
  const chunkSize = Math.max(6, Math.ceil(total / Math.max(2, Math.ceil(durationSeconds / 6))));
  const fallback = [];
  for (let index = 0; index < total; index += chunkSize) {
    const start = (index / total) * durationSeconds;
    const end = (Math.min(total, index + chunkSize) / total) * durationSeconds;
    fallback.push({
      start: roundTime(start),
      end: roundTime(Math.max(start + 1.4, end)),
      text: plainWords.slice(index, index + chunkSize).join(' '),
    });
  }
  return fallback;
}

function buildOverlayTimeline(
  segments: Array<{start: number; end: number; text: string}>,
  request: ReelPlanRequest,
  language: 'english' | 'hinglish',
  scriptDetails: ScriptDetails,
  templateName: ReelTemplateName,
) {
  const directedPlan = buildOverlayTimelineFromScriptDetails(scriptDetails, request, language, templateName, segments);
  if (directedPlan.length) return directedPlan;

  const groups: Array<{start: number; end: number; text: string}> = [];
  let current: {start: number; end: number; texts: string[]} | null = null;

  for (const segment of segments) {
    const duration = current ? segment.end - current.start : 0;
    const shouldStartNew =
      !current ||
      duration >= MAX_OVERLAY_SECONDS ||
      (duration >= MIN_OVERLAY_SECONDS && /[.!?]$/.test(current.texts.join(' ')));

    if (shouldStartNew) {
      if (current) groups.push({start: current.start, end: current.end, text: current.texts.join(' ')});
      current = {start: segment.start, end: segment.end, texts: [segment.text]};
    } else {
      current!.end = segment.end;
      current!.texts.push(segment.text);
    }
  }
  if (current) groups.push({start: current.start, end: current.end, text: current.texts.join(' ')});

  const usedDetailBlockIds = new Set<string>();

  return groups.map((group, index) => {
    const isFirst = index === 0;
    const isLast = index === groups.length - 1;
    const text = cleanDisplayText(group.text);
    const detailBlock = pickDetailBlockForText(text, scriptDetails, index, usedDetailBlockIds);
    if (detailBlock) usedDetailBlockIds.add(detailBlock.id);
    const title = detailBlock?.title || makeOverlayTitle(text, isFirst, language);
    const body = detailBlock ? detailBlock.items.slice(0, 4).join(' | ') : makeOverlayBody(text, title);
    const type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta' =
      isFirst ? 'hook' : isLast ? 'cta' : detailBlock ? overlayTypeForDetail(detailBlock.type) : inferOverlayType(text);

    return withOverlayDirection({
      id: `overlay-${String(index + 1).padStart(2, '0')}`,
      start: roundTime(group.start),
      end: roundTime(group.end),
      type,
      label: isFirst ? 'Hook' : isLast ? 'Final Point' : detailBlock ? detailBlock.title : labelForType(type),
      text: title,
      body,
      accentWord: pickAccentWord(title, request.topicTitle || request.topic),
      align: isFirst || title.length < 22 ? 'center' as const : 'left' as const,
      sfx: isFirst ? 'softPop' as const : isLast ? 'softChime' as const : 'softTick' as const,
    }, detailBlock?.type, undefined, templateName);
  });
}

function buildOverlayTimelineFromScriptDetails(
  scriptDetails: ScriptDetails,
  request: ReelPlanRequest,
  language: 'english' | 'hinglish',
  templateName: ReelTemplateName,
  segments: Array<{start: number; end: number; text: string}> = [],
) {
  const expandedPlan = templateName === 'HANDWRITTEN_NOTES'
    ? expandHandwrittenNotePlan(scriptDetails.videoUsePlan || [])
    : scriptDetails.videoUsePlan || [];
  const plan = templateName === 'HANDWRITTEN_NOTES'
    ? alignHandwrittenPlanToSegments(expandedPlan, segments)
    : expandedPlan;
  if (!plan.length) return [];
  return plan
    .map((item, index) => {
      const isVideoExplainer = templateName === 'VIDEO_EXPLAINER';
      const title = cleanDisplayText(item.renderText || item.displayText || item.title || item.sourceText).slice(0, 90);
      const bodySource = isVideoExplainer
        ? item.renderBody || item.body || ''
        : item.renderBody || item.body || item.sourceText || '';
      const type = overlayTypeForScriptUse(item.purpose, item.detailType, index, plan.length);
      return withOverlayDirection({
        id: item.id || `overlay-${String(index + 1).padStart(2, '0')}`,
        start: roundTime(item.start),
        end: roundTime(item.end),
        type,
        label: item.title || labelForType(type),
        text: isVideoExplainer
          ? trimWords(title || makeOverlayTitle(item.sourceText || scriptDetails.summary, index === 0, language), 8)
          : title || makeOverlayTitle(item.sourceText || scriptDetails.summary, index === 0, language),
        body: isVideoExplainer
          ? trimWords(cleanDisplayText(bodySource), 12)
          : cleanDisplayText(bodySource).slice(0, 140),
        accentWord: pickAccentWord(title || item.title, request.topicTitle || request.topic || scriptDetails.topic),
        align: index === 0 || title.length < 24 ? 'center' as const : 'left' as const,
        sfx: index === 0 ? 'softPop' as const : index === plan.length - 1 ? 'softChime' as const : 'softTick' as const,
      }, item.detailType, item, templateName);
    })
    .filter((item) => item.end > item.start && item.text);
}

function expandHandwrittenNotePlan(plan: NonNullable<ScriptDetails['videoUsePlan']>) {
  const expanded: NonNullable<ScriptDetails['videoUsePlan']> = [];

  for (const item of plan) {
    const parts = uniqueReadableTextParts([
      item.renderText || item.displayText || item.title,
      ...splitNoteBeatText(item.renderBody || item.body),
    ]).slice(0, 4);

    if (parts.length <= 1) {
      expanded.push({
        ...item,
        renderText: trimWords(parts[0] || item.renderText || item.displayText || item.title, 7),
        renderBody: trimWords(item.renderBody || item.body || '', 10),
      });
      continue;
    }

    const totalDuration = Math.max(2.4, item.end - item.start);
    const beatDuration = Math.max(2.2, totalDuration / parts.length);
    parts.forEach((part, index) => {
      const start = roundTime(item.start + index * beatDuration);
      const end = roundTime(index === parts.length - 1 ? item.end : Math.min(item.end, start + beatDuration));
      if (end <= start) return;
      expanded.push({
        ...item,
        id: `${item.id || 'note'}-beat-${index + 1}`,
        start,
        end,
        purpose: index === 0 ? item.purpose : 'point',
        layout: index === 0 ? item.layout : 'checklistCard',
        visual: getHandwrittenBeatVisual(item.visual, item.detailType, item.purpose, part, index),
        animation: 'fadeUp',
        title: part,
        displayText: part,
        body: '',
        renderText: trimWords(part, 7),
        renderBody: '',
        sourceText: item.sourceText,
      });
    });
  }

  return expanded.slice(0, 18);
}

function getHandwrittenBeatVisual(
  visual: string,
  detailType: NonNullable<ScriptDetails['videoUsePlan']>[number]['detailType'],
  purpose: NonNullable<ScriptDetails['videoUsePlan']>[number]['purpose'],
  text: string,
  index: number,
) {
  const token = getHandwrittenVisualToken(visual, purpose === 'warning' ? 'warning' : purpose === 'cta' ? 'cta' : 'point', detailType, text);
  if (index === 0) return token;
  if (
    token === 'document_checklist' ||
    token === 'timeline_strip' ||
    token === 'formula_box' ||
    token === 'comparison_table' ||
    token === 'exam_date_card' ||
    token === 'mind_map' ||
    token === 'pros_cons_table' ||
    token === 'step_ladder' ||
    token === 'flowchart_box' ||
    token === 'before_after_box' ||
    token === 'calendar_reminder' ||
    token === 'ranked_list' ||
    token === 'quote_card'
  ) return token;
  if (purpose === 'warning') return 'effect_xmark';
  if (purpose === 'action' || purpose === 'cta') return 'effect_checkmark';
  return 'bullet_write';
}

function alignHandwrittenPlanToSegments(
  plan: NonNullable<ScriptDetails['videoUsePlan']>,
  segments: Array<{start: number; end: number; text: string}>,
) {
  if (!plan.length || !segments.length) return plan;
  const usedSegments = new Set<number>();
  return plan.map((item, index) => {
    const source = cleanDisplayText([item.sourceText, item.renderText, item.renderBody, item.displayText, item.body].filter(Boolean).join(' '));
    const bestIndex = findBestSegmentIndex(source, segments, usedSegments, index);
    const segment = segments[bestIndex];
    if (!segment) return item;
    usedSegments.add(bestIndex);
    const originalDuration = Math.max(1.2, item.end - item.start);
    const segmentDuration = Math.max(1.2, segment.end - segment.start);
    const duration = Math.min(Math.max(originalDuration, segmentDuration), 5.2);
    return {
      ...item,
      start: roundTime(segment.start),
      end: roundTime(Math.max(segment.start + 1.2, Math.min(segment.end, segment.start + duration))),
      sourceText: item.sourceText || segment.text,
    };
  });
}

function findBestSegmentIndex(
  source: string,
  segments: Array<{start: number; end: number; text: string}>,
  usedSegments: Set<number>,
  fallbackIndex: number,
) {
  const sourceWords = tokenSet(source);
  let bestIndex = -1;
  let bestScore = 0;
  segments.forEach((segment, index) => {
    if (usedSegments.has(index)) return;
    const segmentWords = tokenSet(segment.text);
    const overlap = [...sourceWords].filter((word) => segmentWords.has(word)).length;
    const score = overlap / Math.max(1, Math.min(sourceWords.size || 1, segmentWords.size || 1));
    if (score > bestScore) {
      bestScore = score;
      bestIndex = index;
    }
  });
  if (bestIndex >= 0 && bestScore >= 0.15) return bestIndex;
  return Math.min(segments.length - 1, Math.max(0, fallbackIndex));
}

function tokenSet(value: string) {
  return new Set(
    cleanDisplayText(value)
      .toLowerCase()
      .split(/\s+/)
      .map((word) => word.replace(/[^a-z0-9]+/g, ''))
      .filter((word) => word.length >= 3),
  );
}

function splitNoteBeatText(value: string) {
  return cleanDisplayText(value)
    .split(/\s+\|\s+|(?:^|\s)[•\-]\s+|(?<=[.!?])\s+/)
    .map((item) => item.replace(/^[•\-]\s*/g, '').trim())
    .filter(Boolean);
}

function uniqueReadableTextParts(items: string[]) {
  const seen = new Set<string>();
  const output: string[] = [];
  for (const item of items.map((value) => cleanDisplayText(value)).filter(Boolean)) {
    const key = item.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    output.push(item);
  }
  return output;
}

function withOverlayDirection<T extends {
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta';
  text: string;
  body?: string;
}>(
  overlay: T,
  detailType?: ScriptDetails['detailBlocks'][number]['type'],
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
  templateName: ReelTemplateName = 'VIDEO_EXPLAINER',
): T & {
  layout: ReelOverlayLayout;
  visual: string;
  visualRole: ReelOverlayVisualRole;
  primaryVisual: ReelPrimaryVisual;
  animation: ReelOverlayAnimation;
  emotion: ReelOverlayEmotion;
} {
  const visual = getOverlayVisualDirection(overlay, detailType, planItem, templateName);
  return {
    ...overlay,
    layout: getOverlayLayout(overlay.type, detailType, planItem),
    visual,
    visualRole: getOverlayVisualRole(templateName, overlay.type),
    primaryVisual: getOverlayPrimaryVisual(templateName, overlay, detailType, planItem),
    animation: getOverlayAnimation(overlay.type, planItem),
    emotion: getOverlayEmotion(overlay.type, planItem),
    ...normalizeHandwrittenOverlayMetadata(templateName, {...overlay, visual}),
  };
}

function normalizeHandwrittenOverlayMetadata(
  templateName: ReelTemplateName,
  overlay: {
    type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta';
    text: string;
    body?: string;
    visual?: string;
    start?: number;
    end?: number;
  },
) {
  if (templateName !== 'HANDWRITTEN_NOTES') return {};
  const visual = getHandwrittenVisualToken(overlay.visual || '', overlay.type, undefined, overlay.text, overlay.body);
  const sceneType = getHandwrittenSceneType(visual, overlay.type);
  const noteItems = getHandwrittenNoteItems(overlay.text, overlay.body, overlay.type, visual);
  const diagram = getHandwrittenDiagram(visual, overlay.text, overlay.body);
  const annotations = getHandwrittenAnnotations(visual, overlay.text, overlay.body);
  const revealPlan = getHandwrittenRevealPlan(overlay, visual, noteItems, annotations);
  return {
    visual,
    sceneType,
    noteItems,
    diagram,
    annotations,
    revealPlan,
  };
}

function getHandwrittenVisualToken(
  value: string,
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta',
  detailType?: ScriptDetails['detailBlocks'][number]['type'],
  text = '',
  body = '',
) {
  const explicit = cleanDisplayText(value).toLowerCase();
  const allowed = [
    'heading_write',
    'bullet_write',
    'diagram_flowchart',
    'diagram_timeline',
    'diagram_mindmap',
    'formula_box',
    'comparison_table',
    'timeline_strip',
    'document_checklist',
    'exam_date_card',
    'mind_map',
    'pros_cons_table',
    'step_ladder',
    'flowchart_box',
    'before_after_box',
    'calendar_reminder',
    'ranked_list',
    'quote_card',
    'effect_bracket',
    'effect_checkmark',
    'effect_xmark',
    'arrow_diagram',
    'highlight_swipe',
    'red_circle',
  ];
  if (allowed.includes(explicit)) return explicit;

  const source = cleanDisplayText([value, text, body].filter(Boolean).join(' ')).toLowerCase();
  if (type === 'hook') return 'heading_write';
  if (/quote|believe|yakeen|confidence|khud par|motivation|hope|himmat/.test(source)) return 'quote_card';
  if (type === 'warning' || detailType === 'warningBox' || /mistake|avoid|wrong|risk|nahi|no response/.test(source)) return 'effect_xmark';
  if (/rejection|reject|failure|fail|seekh|learning/.test(source)) return 'before_after_box';
  if (detailType === 'dateBox' || /exam date|admit card|deadline|last date|result date|important date/.test(source)) return 'exam_date_card';
  if (/calendar|reminder|date|deadline|expected|april|january|february|march|may|june|july|august|september|october|november|december/.test(source)) return 'calendar_reminder';
  if (detailType === 'documentList' || /document|resume|cv|aadhaar|pan card|photo|signature|upload|proof/.test(source)) return 'document_checklist';
  if (/top\s*\d|rank|priority|important points|sabse/.test(source)) return 'ranked_list';
  if (/pros|cons|advantages|disadvantages|benefit|drawback/.test(source)) return 'pros_cons_table';
  if (/before|after|degree|skills|old|new|pehle|baad/.test(source)) return 'before_after_box';
  if (/growth|level|stage|career|skills|skill|progress|improve|better/.test(source)) return 'step_ladder';
  if (detailType === 'processList' || /step|process|apply|submit|download|continue|daily|habit|practice/.test(source)) return 'timeline_strip';
  if (detailType === 'amountBox' || /salary|fee|amount|percentage|score|formula|calculate|eligibility|ability/.test(source)) return 'formula_box';
  if (/category|categories|types|benefits|branches|points/.test(source)) return 'mind_map';
  if (/cause|effect|because|leads to|result/.test(source)) return 'flowchart_box';
  if (/compare|versus|\bvs\b|difference/.test(source)) return 'comparison_table';
  if (type === 'stat') return 'highlight_swipe';
  if (type === 'cta' || /believe|work|action|next|apply/.test(source)) return 'effect_checkmark';
  return 'bullet_write';
}

function getHandwrittenSceneType(visual: string, type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta') {
  if (type === 'hook' || visual === 'heading_write') return 'noteTitleScene';
  if (visual === 'formula_box') return 'formulaBoxScene';
  if (visual === 'comparison_table') return 'comparisonTableScene';
  if (visual === 'timeline_strip') return 'timelineStripScene';
  if (visual === 'document_checklist') return 'documentChecklistScene';
  if (visual === 'exam_date_card') return 'examDateCardScene';
  if (visual === 'mind_map') return 'mindmapScene';
  if (visual === 'pros_cons_table') return 'prosConsScene';
  if (visual === 'step_ladder') return 'stepLadderScene';
  if (visual === 'flowchart_box') return 'flowchartScene';
  if (visual === 'before_after_box') return 'beforeAfterScene';
  if (visual === 'calendar_reminder') return 'calendarReminderScene';
  if (visual === 'ranked_list') return 'rankedListScene';
  if (visual === 'quote_card') return 'quoteNoteScene';
  if (visual === 'effect_xmark' || visual === 'red_circle' || type === 'warning') return 'mistakeCorrectionScene';
  if (visual === 'diagram_flowchart' || visual === 'arrow_diagram') return 'flowchartScene';
  if (visual === 'diagram_timeline') return 'timelineScene';
  if (visual === 'diagram_mindmap') return 'mindmapScene';
  if (type === 'cta') return 'summaryBoxScene';
  return 'bulletLessonScene';
}

function getHandwrittenNoteItems(text: string, body = '', type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta', visual: string) {
  const parts = uniqueReadableTextParts([
    cleanDisplayText(body),
    ...cleanDisplayText(body).split(/\s+\|\s+|,\s+|(?<=[.!?])\s+/),
  ]).filter((item) => item && !isSameShortText(item, text)).slice(0, 3);
  const icon =
    type === 'warning' || visual === 'effect_xmark'
      ? 'warning' as const
      : visual === 'effect_checkmark' || visual === 'document_checklist'
        ? 'check' as const
        : visual === 'timeline_strip' || visual === 'step_ladder' || visual === 'ranked_list'
          ? 'number' as const
          : 'dot' as const;
  return (parts.length ? parts : [body || text])
    .filter(Boolean)
    .slice(0, 3)
    .map((item) => ({text: trimWords(item, 8), icon}));
}

function getHandwrittenDiagram(visual: string, text: string, body = '') {
  const nodes = uniqueReadableTextParts([text, ...cleanDisplayText(body).split(/\s+\|\s+|,\s+/)])
    .map((item) => trimWords(item, 4))
    .filter(Boolean)
    .slice(0, 5);
  const fallbackNodes = nodes.length >= 2 ? nodes : [trimWords(text, 4), 'Next Step', 'Action'];
  if (visual === 'comparison_table' || visual === 'pros_cons_table' || visual === 'before_after_box') return {type: 'comparison' as const, nodes: fallbackNodes.slice(0, 4), activeNode: fallbackNodes[0]};
  if (visual === 'timeline_strip' || visual === 'exam_date_card' || visual === 'calendar_reminder' || visual === 'step_ladder' || visual === 'ranked_list') return {type: 'timeline' as const, nodes: fallbackNodes.slice(0, 5), activeNode: fallbackNodes.at(-1)};
  if (visual === 'diagram_mindmap' || visual === 'mind_map') return {type: 'mindmap' as const, nodes: fallbackNodes.slice(0, 5), activeNode: fallbackNodes[0]};
  return {type: 'flowchart' as const, nodes: fallbackNodes.slice(0, 5), activeNode: fallbackNodes[0]};
}

function getHandwrittenAnnotations(visual: string, text: string, body = '') {
  const targetText = trimWords(pickAccentWord(text, body) || text, 4);
  if (visual === 'effect_xmark') return [{type: 'side_note' as const, targetText, label: 'avoid'}];
  if (visual === 'exam_date_card' || visual === 'calendar_reminder' || visual === 'red_circle') return [{type: 'red_circle' as const, targetText}];
  if (visual === 'effect_checkmark') return [{type: 'underline' as const, targetText}];
  if (visual === 'timeline_strip' || visual === 'step_ladder' || visual === 'flowchart_box' || visual === 'arrow_diagram') return [{type: 'arrow_diagram' as const, targetText, label: 'next'}];
  if (visual === 'highlight_swipe' || visual === 'formula_box' || visual === 'quote_card') return [{type: 'highlight_swipe' as const, targetText}];
  return [{type: 'underline' as const, targetText}];
}

function getHandwrittenRevealPlan(
  overlay: {text: string; body?: string; start?: number; end?: number},
  visual: string,
  noteItems: Array<{text: string}>,
  annotations: Array<{type: string; targetText: string}>,
) {
  const duration = Math.max(1.2, Number(overlay.end || 0) - Number(overlay.start || 0));
  const entries = [
    {text: trimWords(overlay.text, 7), token: 'heading_write'},
    ...noteItems.map((item) => ({text: trimWords(item.text, 8), token: 'bullet_write'})),
    ...annotations.map((item) => ({
      text: trimWords(item.targetText, 5),
      token: item.type === 'red_circle' ? 'red_circle' : item.type === 'arrow_diagram' ? 'arrow_diagram' : visual,
    })),
  ].filter((item) => item.text).slice(0, 6);
  const step = duration / Math.max(1, entries.length);
  return entries.map((entry, index) => ({
    ...entry,
    start: roundTime(index * step),
    end: roundTime(Math.min(duration, index * step + Math.max(0.8, step * 0.82))),
  }));
}

function isSameShortText(a: string, b: string) {
  const left = cleanDisplayText(a).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  const right = cleanDisplayText(b).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  return Boolean(left && right && (left === right || left.includes(right) || right.includes(left)));
}

function getOverlayPrimaryVisual(
  templateName: ReelTemplateName,
  overlay: {type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta'; text: string; body?: string},
  detailType?: ScriptDetails['detailBlocks'][number]['type'],
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
): ReelPrimaryVisual {
  const source = cleanDisplayText([planItem?.visual, overlay.text, overlay.body].filter(Boolean).join(' '));
  if (templateName === 'VIDEO_CAPTION') return {type: 'uploadedMedia', label: 'Uploaded video', motion: 'slowZoom'};
  if (templateName === 'IMAGE_STORY') return {type: 'image', label: 'Story image', prompt: source, motion: 'slowZoom'};
  if (templateName === 'HANDWRITTEN_NOTES') return {type: 'document', label: 'Notebook scene', prompt: source, motion: 'slideUp'};
  if (overlay.type === 'hook') return {type: 'waveform', label: 'Audio story pulse', prompt: source, motion: 'float'};
  if (overlay.type === 'stat' || detailType === 'amountBox' || detailType === 'dateBox') return {type: 'chart', label: extractStatToken(source) || 'Key number', prompt: source, motion: 'pop'};
  if (overlay.type === 'warning' || detailType === 'warningBox') return {type: 'icon', label: 'Warning', prompt: source, motion: 'pop'};
  if (detailType === 'documentList') return {type: 'document', label: 'Documents', prompt: source, motion: 'slideUp'};
  if (detailType === 'processList') return {type: 'mockup', label: 'Process flow', prompt: source, motion: 'panLeft'};
  if (detailType === 'websiteBox') return {type: 'mockup', label: 'Website frame', prompt: source, motion: 'slowZoom'};
  return {type: 'icon', label: pickAccentWord(overlay.text, planItem?.title), prompt: source, motion: 'float'};
}

function getOverlayVisualRole(
  templateName: ReelTemplateName,
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta',
): ReelOverlayVisualRole {
  if (templateName === 'HANDWRITTEN_NOTES') return type === 'hook' ? 'background' : 'assetInsert';
  if (templateName === 'VIDEO_CAPTION') return 'topVideo';
  if (templateName === 'IMAGE_STORY') return 'background';
  return 'bottomOverlay';
}

function getOverlayLayout(
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta',
  detailType?: ScriptDetails['detailBlocks'][number]['type'],
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
): ReelOverlayLayout {
  if (planItem?.layout === 'hookCard' || planItem?.layout === 'quoteCard') return 'headlineCard';
  if (planItem?.layout === 'statCard') return 'statCard';
  if (planItem?.layout === 'warningCard') return 'warningCard';
  if (planItem?.layout === 'checklistCard') return 'checklist';
  if (planItem?.layout === 'ctaCard') return 'ctaCard';
  if (planItem?.layout === 'splitExplainer') return 'splitExplainer';
  if (type === 'hook' || type === 'quote') return 'headlineCard';
  if (type === 'stat' || detailType === 'amountBox' || detailType === 'dateBox') return 'statCard';
  if (type === 'warning' || detailType === 'warningBox') return 'warningCard';
  if (type === 'cta') return 'ctaCard';
  if (detailType === 'processList' || detailType === 'documentList') return 'checklist';
  return 'splitExplainer';
}

function getOverlayAnimation(
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta',
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
): ReelOverlayAnimation {
  if (planItem?.animation === 'popIn') return 'popIn';
  if (planItem?.animation === 'fadeUp' || planItem?.animation === 'none') return 'fadeUp';
  if (planItem?.animation === 'slideUp') return 'slideUp';
  if (planItem?.animation === 'countUp') return 'countUp';
  if (planItem?.animation === 'pulse') return 'warningPulse';
  if (type === 'hook') return 'popIn';
  if (type === 'stat') return 'countUp';
  if (type === 'warning') return 'warningPulse';
  if (type === 'cta') return 'slideUp';
  return 'fadeUp';
}

function getOverlayEmotion(
  type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta',
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
): ReelOverlayEmotion {
  if (planItem?.emotion === 'urgent') return 'urgent';
  if (planItem?.emotion === 'serious') return 'serious';
  if (planItem?.emotion === 'motivational') return 'motivational';
  if (planItem?.emotion === 'informative' || planItem?.emotion === 'neutral') return 'informative';
  if (type === 'hook') return 'urgent';
  if (type === 'warning') return 'serious';
  if (type === 'cta') return 'motivational';
  return 'informative';
}

function getOverlayVisualDirection(
  overlay: {type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta'; text: string; body?: string},
  detailType?: ScriptDetails['detailBlocks'][number]['type'],
  planItem?: NonNullable<ScriptDetails['videoUsePlan']>[number],
  templateName: ReelTemplateName = 'VIDEO_EXPLAINER',
) {
  if (templateName === 'HANDWRITTEN_NOTES') {
    return getHandwrittenVisualToken(planItem?.visual || '', overlay.type, detailType, overlay.text, overlay.body);
  }
  if (planItem?.visual) return planItem.visual;
  if (overlay.type === 'hook') return 'top video dominant; bottom uses a large punchy hook with one highlighted keyword';
  if (overlay.type === 'stat' || detailType === 'amountBox') return 'top video continues; bottom emphasizes the number or fee in a strong stat card';
  if (detailType === 'dateBox') return 'top video continues; bottom shows date/deadline as a clear key-number moment';
  if (overlay.type === 'warning' || detailType === 'warningBox') return 'top video continues; bottom uses a serious warning card with high contrast';
  if (detailType === 'processList') return 'top video continues; bottom turns the process into a short checklist';
  if (detailType === 'documentList') return 'top video continues; bottom shows required items as a concise checklist';
  if (overlay.type === 'cta') return 'top video continues; bottom closes with a clean action card';
  return 'top video stays primary; bottom explains the current idea with short creator-style text';
}

function getSceneComplexity(type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta') {
  if (type === 'stat') return 0.55;
  if (type === 'warning') return 0.65;
  if (type === 'hook') return 0.5;
  if (type === 'cta') return 0.4;
  return 0.35;
}

function getVisualEnergy(type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta', index: number, total: number) {
  if (index === 0 || type === 'hook') return 0.72;
  if (type === 'warning') return 0.68;
  if (type === 'stat') return 0.6;
  if (index === total - 1 || type === 'cta') return 0.5;
  return 0.45;
}

function buildSuggestedAssets(scriptDetails: ScriptDetails, templateName: ReelTemplateName) {
  if (templateName === 'HANDWRITTEN_NOTES') {
    return [
      'clean paper-style canvas',
      'editorial cards',
      'small checklist markers',
      ...matchVisualAssetsForScript(scriptDetails, 4),
    ].slice(0, 12);
  }
  if (templateName === 'IMAGE_STORY') {
    return [
      'uploaded image as primary visual',
      'selected image assets only when user supplied or explicitly enabled',
      'subtle cinematic motion per scene',
      'minimal safe-zone text overlays',
      ...(scriptDetails.imageSelectionPlan || []).map((item) => `image need: ${item.bestMatchDescription}`),
      ...matchVisualAssetsForScript(scriptDetails, 4),
    ].slice(0, 12);
  }
  const suggestions = [
    ...(scriptDetails.assetBriefs || []).map((item) => item.searchText || item.title || '').filter(Boolean),
    ...(scriptDetails.imageUsagePolicy
      ? [`image count policy: min ${scriptDetails.imageUsagePolicy.minImages}, max ${scriptDetails.imageUsagePolicy.maxImages}, recommended ${scriptDetails.imageUsagePolicy.recommendedImages}`]
      : []),
    ...(scriptDetails.imageSelectionPlan || []).map((item) => [
      `image need: ${item.bestMatchDescription}`,
      `tags: ${item.requiredTags.join(', ')}`,
      item.avoidTags.length ? `avoid: ${item.avoidTags.join(', ')}` : '',
      `fallback: ${item.fallbackVisual}`,
    ].filter(Boolean).join(' | ')),
    ...(scriptDetails.websites || []).map((item) => `website screenshot: ${item}`),
    ...(scriptDetails.amounts || []).map((item) => `number emphasis: ${item}`),
    ...matchVisualAssetsForScript(scriptDetails, 8),
  ];
  return Array.from(new Set(suggestions)).slice(0, 12);
}

function overlayTypeForScriptUse(
  purpose: NonNullable<ScriptDetails['videoUsePlan']>[number]['purpose'],
  detailType: NonNullable<ScriptDetails['videoUsePlan']>[number]['detailType'],
  index: number,
  total: number,
): 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta' {
  if (index === 0 || purpose === 'hook') return 'hook';
  if (index === total - 1 || purpose === 'cta') return 'cta';
  if (purpose === 'warning' || detailType === 'warningBox') return 'warning';
  if (purpose === 'date' || detailType === 'dateBox' || detailType === 'amountBox') return 'stat';
  if (purpose === 'proof') return 'quote';
  return 'point';
}

function inferOverlayType(text: string): 'point' | 'stat' | 'warning' | 'quote' {
  if (/[0-9₹$%]/.test(text)) return 'stat';
  if (/\b(nahi|nahin|warning|risk|galti|problem|lekin|but|danger|avoid)\b/i.test(text)) return 'warning';
  if (text.length <= 28) return 'quote';
  return 'point';
}

function pickDetailBlockForText(
  text: string,
  scriptDetails: ScriptDetails,
  index: number,
  usedDetailBlockIds: Set<string>,
) {
  if (index === 0) return null;
  const normalized = text.toLowerCase();
  const candidates = scriptDetails.detailBlocks.filter((block) => !usedDetailBlockIds.has(block.id));
  return candidates.find((block) => {
    if (block.type === 'websiteBox') {
      return /\b(website|site|portal|link|open|visit)\b/i.test(text) || block.items.some((item) => normalized.includes(item.toLowerCase()));
    }
    if (block.type === 'amountBox') {
      return /\b(₹|rs|rupees|fee|fees|payment|amount|cost|charge)\b/i.test(text) || block.items.some((item) => normalized.includes(item.toLowerCase()));
    }
    if (block.type === 'documentList') {
      return /\b(document|documents|proof|card|photo|signature|certificate)\b/i.test(text) || block.items.some((item) => normalized.includes(item.toLowerCase()));
    }
    if (block.type === 'dateBox') {
      return /\b(date|deadline|last date|exam|admit card|hall ticket)\b/i.test(text) || block.items.some((item) => normalized.includes(item.toLowerCase()));
    }
    if (block.type === 'warningBox') {
      return /\b(deadline|galti|mistake|avoid|warning|required|mandatory|reject|problem|risk)\b/i.test(text);
    }
    if (block.type === 'processList') {
      return /\b(apply|download|fill|submit|upload|register|login|verify|check|pay|open|visit|click)\b/i.test(text);
    }
    return false;
  }) || null;
}

function overlayTypeForDetail(type: ScriptDetails['detailBlocks'][number]['type']): 'point' | 'stat' | 'warning' | 'quote' {
  if (type === 'amountBox' || type === 'dateBox') return 'stat';
  if (type === 'warningBox') return 'warning';
  if (type === 'websiteBox' || type === 'documentList' || type === 'processList') return 'point';
  return 'quote';
}

function labelForType(type: string) {
  if (type === 'stat') return 'Number';
  if (type === 'warning') return 'Reality';
  if (type === 'quote') return 'Note';
  return 'Point';
}

function makeOverlayTitle(text: string, isFirst: boolean, language: 'english' | 'hinglish') {
  const cleaned = removeWeakIntroPhrases(cleanDisplayText(text));
  const entityTitle = extractEntityTitle(cleaned);
  if (entityTitle && (isFirst || entityTitle.split(/\s+/).length >= 2)) return entityTitle;
  const words = cleaned.split(/\s+/).filter(Boolean);
  if (!words.length) return language === 'hinglish' ? 'Suno' : 'Watch this';
  const filteredWords = words.filter((word) => !TITLE_FILLER_WORDS.has(word.toLowerCase().replace(/[^a-z0-9]+/g, '')));
  const limit = isFirst ? 4 : 4;
  return titleCase((filteredWords.length ? filteredWords : words).slice(0, limit).join(' '));
}

function makeOverlayBody(text: string, title: string) {
  const titleWords = new Set(title.toLowerCase().split(/\s+/).map((word) => word.replace(/[^a-z0-9]+/g, '')));
  const bodyWords = text
    .split(/\s+/)
    .filter((word, index) => index > 1 || !titleWords.has(word.toLowerCase().replace(/[^a-z0-9]+/g, '')));
  return trimWords(bodyWords.join(' '), 18);
}

function pickAccentWord(title: string, topic?: string) {
  const topicWords = new Set(String(topic || '').toLowerCase().split(/\s+/).filter(Boolean));
  const words = title.split(/\s+/).filter(Boolean);
  return (
    words.find((word) => /[0-9₹$%]/.test(word)) ||
    words.find((word) => topicWords.has(word.toLowerCase())) ||
    words.find((word) => word.length >= 4) ||
    words[0]
  );
}

function deriveTopicTitle(segments: Array<{text: string}>, transcript: string) {
  const source = removeWeakIntroPhrases([segments[0]?.text, segments[1]?.text, transcript].filter(Boolean).join(' '));
  const entityTitle = extractEntityTitle(source);
  if (entityTitle) return cleanTitle(entityTitle);

  const importantWords = cleanDisplayText(source)
    .split(/\s+/)
    .filter((word) => {
      const normalized = word.toLowerCase().replace(/[^a-z0-9]+/g, '');
      return normalized && !TITLE_FILLER_WORDS.has(normalized) && normalized.length > 2;
    });

  return titleCase(trimWords(importantWords.join(' ') || 'Video reel', 5));
}

function cleanTitle(value?: string) {
  const source = cleanDisplayText(value || '');
  return source ? titleCase(trimWords(removeWeakIntroPhrases(source), 5)) : undefined;
}

const TITLE_FILLER_WORDS = new Set([
  'aaj',
  'ab',
  'apko',
  'aap',
  'aur',
  'bata',
  'bhi',
  'hai',
  'hain',
  'ho',
  'hota',
  'hoti',
  'hum',
  'ka',
  'kar',
  'karte',
  'ke',
  'ki',
  'kya',
  'lekin',
  'me',
  'mein',
  'milta',
  'na',
  'naam',
  'nahi',
  'nahin',
  'ne',
  'se',
  'sirf',
  'suna',
  'the',
  'this',
  'to',
  'video',
  'ye',
]);

function removeWeakIntroPhrases(value: string) {
  return cleanDisplayText(value)
    .replace(/\bnaam suna hai na\b/gi, ' ')
    .replace(/\bsuna hai na\b/gi, ' ')
    .replace(/\baaj hum\b/gi, ' ')
    .replace(/\blets?\s+be\s+real\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractEntityTitle(value: string) {
  const cleaned = cleanDisplayText(value);
  const acronymMatch = cleaned.match(
    /\b([A-Z]{2,}(?:\s+(?:[A-Z][a-z0-9]+|[A-Z0-9]{1,4})){0,4})\b/,
  );
  if (acronymMatch?.[1]) {
    return titleCase(trimWords(acronymMatch[1], 5));
  }

  const titleishMatch = cleaned.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z0-9]+){1,3})\b/);
  if (titleishMatch?.[1]) return titleCase(trimWords(titleishMatch[1], 5));

  return '';
}

function detectLanguage(text: string): 'english' | 'hinglish' {
  return /\b(hai|hain|nahi|nahin|kya|kaise|kyun|lekin|aur|bhi|aap|apko|karna|hoga|hoti|mein|me)\b/i.test(text)
    ? 'hinglish'
    : 'english';
}

function estimateSpeechDensity(transcript: string, durationSeconds: number): 'slow' | 'medium' | 'fast' {
  const wps = transcript.split(/\s+/).filter(Boolean).length / Math.max(1, durationSeconds);
  if (wps > 2.8) return 'fast';
  if (wps < 1.45) return 'slow';
  return 'medium';
}

function estimateHookStrength(text: string) {
  if (/[?!%]|\b(secret|mistake|warning|stop|free|today|naam suna|real)\b/i.test(text)) return 0.78;
  return 0.62;
}

function chunkWords(words: ReelWord[], size: number) {
  const chunks: ReelWord[][] = [];
  for (let index = 0; index < words.length; index += size) {
    chunks.push(words.slice(index, index + size));
  }
  return chunks;
}

function cleanDisplayText(value: string) {
  return String(value || '')
    .replace(/[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\s+([,.!?;:])/g, '$1')
    .trim();
}

function trimWords(value: string, maxWords: number) {
  const words = cleanDisplayText(value).split(/\s+/).filter(Boolean);
  if (words.length <= maxWords) return words.join(' ');
  return `${words.slice(0, maxWords).join(' ')}...`;
}

function titleCase(value: string) {
  return cleanDisplayText(value)
    .split(/\s+/)
    .map((word) => {
      if (/^[A-Z0-9]{2,}$/.test(word)) return word;
      return word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join(' ');
}

function getMaxOpenAiCallsPerRender() {
  const value = Number(process.env.OPENAI_MAX_CALLS_PER_RENDER || 1);
  if (!Number.isFinite(value)) return 1;
  return Math.max(0, Math.floor(value));
}

function clampPlanNumber(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

function defaultValidationVisual(type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta') {
  if (type === 'hook') return 'large transcript-based hook with one clear focal visual';
  if (type === 'stat') return 'single number or date emphasis matched to the spoken phrase';
  if (type === 'warning') return 'single warning callout matched to the spoken phrase';
  if (type === 'cta') return 'single clean action card matched to the final spoken phrase';
  if (type === 'quote') return 'single quote-style text moment matched to the spoken phrase';
  return 'single explainer visual matched to the active transcript phrase';
}

function normalizePrimaryVisual(
  value: ReelPrimaryVisual | undefined,
  overlay: {type: 'hook' | 'point' | 'stat' | 'warning' | 'quote' | 'cta'; text: string; body?: string; visual?: string},
  mediaType: 'video' | 'audio' | 'image',
): ReelPrimaryVisual {
  const allowedTypes = new Set<ReelPrimaryVisualType>(['uploadedMedia', 'image', 'icon', 'chart', 'document', 'waveform', 'mockup', 'none']);
  const type = value?.type && allowedTypes.has(value.type)
    ? value.type
    : mediaType === 'audio'
      ? overlay.type === 'stat'
        ? 'chart'
        : overlay.type === 'warning'
          ? 'icon'
          : 'waveform'
      : 'uploadedMedia';
  const allowedMotions = new Set<ReelPrimaryVisualMotion>(['slowZoom', 'panLeft', 'float', 'pop', 'slideUp', 'parallax']);
  const prompt = cleanDisplayText(value?.prompt || overlay.visual || [overlay.text, overlay.body].filter(Boolean).join(' ')).slice(0, 180);
  return {
    type,
    assetId: cleanDisplayText(value?.assetId || '').slice(0, 80) || undefined,
    prompt,
    label: cleanDisplayText(value?.label || labelForType(overlay.type)).slice(0, 48),
    motion: value?.motion && allowedMotions.has(value.motion) ? value.motion : defaultPrimaryVisualMotion(type),
  };
}

function defaultPrimaryVisualMotion(type: ReelPrimaryVisualType): ReelPrimaryVisualMotion {
  if (type === 'chart' || type === 'icon') return 'pop';
  if (type === 'document' || type === 'mockup') return 'slideUp';
  if (type === 'image') return 'slowZoom';
  return 'float';
}

function extractStatToken(value?: string) {
  return cleanDisplayText(value || '').match(/[₹$]?\s?\d[\d,.]*(?:\s?(?:%|lakh|crore|k|thousand|days?|hours?|months?|years?))?/i)?.[0] || '';
}

function normalizeVisualKey(value: string) {
  return cleanDisplayText(value).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function uniqueStrings(values: string[]) {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const value of values.map((item) => cleanDisplayText(item)).filter(Boolean)) {
    const key = value.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(value);
  }
  return result;
}

function roundTime(value: number) {
  return Math.round(value * 100) / 100;
}
